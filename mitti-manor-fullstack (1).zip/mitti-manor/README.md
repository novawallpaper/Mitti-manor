# MITTI MANOR — B2B Wholesale E-commerce Platform

A real, full-stack wholesale e-commerce application for **MITTI MANOR**, a
bulk supplier of disposable products (cutlery, cups, packaging, plates,
napkins) to shops, restaurants, cafes and hotels.

```
Frontend (React + TypeScript + Tailwind)
        ↓  REST / JSON
Backend (FastAPI, Python)
        ↓
MongoDB
```

Frontend and backend are fully separate apps in their own folders, talking
only over the REST API — nothing is shared or tangled together, so either
side can be developed, redeployed, or replaced independently.

```
mitti-manor/
  backend/     # FastAPI + MongoDB REST API  (see backend/README.md)
  frontend/    # React + TypeScript + Tailwind SPA (see frontend/README.md)
```

## Quick start (local)

**1. Backend**
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # point MONGO_URI at your MongoDB (Atlas or local)
python seed_db.py           # seeds demo categories/products + demo admin
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**2. Frontend** (in a second terminal)
```bash
cd frontend
npm install
cp .env.example .env        # VITE_API_BASE_URL=http://localhost:8000
npm run dev
```

Open `http://localhost:5173`. Register an account (demo OTP is shown
on-screen — no real SMS is sent), browse the seeded catalog, add to cart,
and check out.

**Demo admin account** (created by `seed_db.py`, for future admin-dashboard
work): mobile `9999999999`, password `admin123`.

## Running in Replit / Bolt

1. Create two services/repls (or one repl with two run configs): one for
   `backend/`, one for `frontend/`.
2. In the backend service, set these as **Secrets** (never commit them):
   `MONGO_URI`, `MONGO_DB_NAME`, `JWT_SECRET_KEY`, `CORS_ORIGINS` (include
   your frontend's Replit/Bolt URL).
3. Use a **MongoDB Atlas** free-tier cluster for `MONGO_URI` — Replit/Bolt
   containers don't run MongoDB themselves.
4. Backend run command: `uvicorn app.main:app --host 0.0.0.0 --port 8000`.
5. In the frontend service, set `VITE_API_BASE_URL` to your backend's
   public Replit/Bolt URL, then `npm install && npm run dev -- --host`.
6. Run `python seed_db.py` once (Shell tab) to load demo data.

## What's implemented

- **Auth**: register/login (mobile or email + password), JWT sessions,
  logout, `/me`, demo OTP verification flow.
- **Business profile**: owner name, business name, mobile, business type,
  GSTIN, address — attached 1:1 to a user account.
- **Products**: categories, images, wholesale price, MOQ, stock, tiered
  bulk pricing, specifications, description, search/filter/sort/pagination.
- **Shopping**: cart (server-persisted per user), wishlist, quantity
  management with MOQ/stock validation.
- **Orders**: checkout (existing or new address), automatic bulk-price
  resolution, unique order numbers, order history, order details with
  status timeline, stock decrement on order.
- **Security**: bcrypt password hashing, JWT-protected private routes,
  Pydantic input validation on every endpoint, all secrets in environment
  variables, nothing sensitive in frontend code.

## What's intentionally deferred (by design, not oversight)

- **Admin dashboard UI** — the backend is already admin-ready: product/
  category CRUD, order-status updates and a `GET /api/orders/admin/all`
  endpoint exist and are protected by an `is_admin` check
  (`app/auth/deps.py::get_current_active_admin`). Build the admin frontend
  against these without touching the API.
- **Real SMS OTP** — isolated entirely in `backend/app/auth/otp.py`. Swap
  its two functions (`send_otp`, `verify_otp`) for a provider call; no
  route or frontend code changes needed.
- **Payment gateway** — orders are created with `status: "pending"` and no
  payment step, ready for a `payments` collection + provider webhook to be
  added later without touching the order schema.
- **Notifications, delivery tracking, production deployment config** — none
  of the current architecture blocks adding these; they're additive.

## Database collections

`users`, `businesses`, `categories`, `products`, `addresses`, `carts`,
`wishlists`, `orders`, `order_items` — see the docstring at the top of each
file in `backend/app/models/` for exact shape and relationships.
