# MITTI MANOR — Frontend (React + TypeScript + Tailwind)

## Setup

```bash
cd frontend
npm install
cp .env.example .env   # set VITE_API_BASE_URL to your backend URL
npm run dev
```

App runs at `http://localhost:5173` and talks to the FastAPI backend at the
URL set in `VITE_API_BASE_URL`.

## Folder structure

```
frontend/
  src/
    api/          # one file per backend resource (axios calls)
    context/      # AuthContext (login/session), CartContext (cart state)
    components/   # Navbar, ProductCard, CategoryFilter, ProtectedRoute, Loader
    pages/        # one file per route
    types/        # TypeScript interfaces mirroring backend Pydantic schemas
    App.tsx        # route definitions
    main.tsx       # app entrypoint
```

## How auth works

- JWT is stored in `localStorage` (`mitti_manor_token`) after login/register.
- `src/api/client.ts` attaches it to every request automatically and clears
  it on a 401 response.
- `AuthContext` exposes `user`, `isAuthenticated`, `login`, `register`,
  `logout` to the whole app.
- `ProtectedRoute` wraps any page that requires login (cart checkout,
  orders, wishlist, profile).

## Demo OTP

Registration calls `POST /api/auth/otp/send`, which — in demo mode — returns
the OTP code directly in the response instead of sending a real SMS. The
Register page shows it on-screen with a "Demo mode" note so you can test
the flow end-to-end without an SMS provider.

## Connecting to the backend

Make sure the FastAPI backend (see `../backend/README.md`) is running and
reachable at the URL in `.env`. CORS on the backend must include this
frontend's origin (`CORS_ORIGINS` in the backend `.env`).
