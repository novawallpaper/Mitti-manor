/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        earth: {
          50: "#faf6f1",
          100: "#f0e6d9",
          200: "#e0cba9",
          300: "#cba76e",
          400: "#b5854a",
          500: "#96693a",
          600: "#7a5230",
          700: "#5f3f27",
          800: "#4a3220",
          900: "#3a281a",
        },
      },
    },
  },
  plugins: [],
};
