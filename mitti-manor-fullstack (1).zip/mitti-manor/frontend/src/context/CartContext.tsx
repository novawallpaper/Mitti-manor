import React, { createContext, useContext, useEffect, useState } from "react";
import { clearCart as apiClearCart, fetchCart, removeCartItem, upsertCartItem } from "../api/cart";
import { Cart } from "../types";
import { useAuth } from "./AuthContext";

interface CartContextValue {
  cart: Cart;
  isLoading: boolean;
  refreshCart: () => Promise<void>;
  setItemQuantity: (productId: string, quantity: number) => Promise<void>;
  removeItem: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
}

const EMPTY_CART: Cart = { items: [], subtotal: 0, total_items: 0 };

const CartContext = createContext<CartContextValue | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  const [cart, setCart] = useState<Cart>(EMPTY_CART);
  const [isLoading, setIsLoading] = useState(false);

  const refreshCart = async () => {
    if (!isAuthenticated) {
      setCart(EMPTY_CART);
      return;
    }
    setIsLoading(true);
    try {
      const data = await fetchCart();
      setCart(data);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    refreshCart();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  const setItemQuantity = async (productId: string, quantity: number) => {
    const updated = await upsertCartItem(productId, quantity);
    setCart(updated);
  };

  const removeItem = async (productId: string) => {
    const updated = await removeCartItem(productId);
    setCart(updated);
  };

  const clearCart = async () => {
    const updated = await apiClearCart();
    setCart(updated);
  };

  return (
    <CartContext.Provider value={{ cart, isLoading, refreshCart, setItemQuantity, removeItem, clearCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
