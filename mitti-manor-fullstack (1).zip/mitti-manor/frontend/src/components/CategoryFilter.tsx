import React from "react";
import { Category } from "../types";

interface Props {
  categories: Category[];
  selectedCategoryId: string | null;
  onSelect: (categoryId: string | null) => void;
}

export default function CategoryFilter({ categories, selectedCategoryId, onSelect }: Props) {
  return (
    <div className="flex flex-wrap gap-2">
      <button
        onClick={() => onSelect(null)}
        className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
          selectedCategoryId === null
            ? "bg-earth-700 text-white border-earth-700"
            : "bg-white text-earth-700 border-earth-200 hover:border-earth-400"
        }`}
      >
        All
      </button>
      {categories.map((cat) => (
        <button
          key={cat.id}
          onClick={() => onSelect(cat.id)}
          className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
            selectedCategoryId === cat.id
              ? "bg-earth-700 text-white border-earth-700"
              : "bg-white text-earth-700 border-earth-200 hover:border-earth-400"
          }`}
        >
          {cat.name}
        </button>
      ))}
    </div>
  );
}
