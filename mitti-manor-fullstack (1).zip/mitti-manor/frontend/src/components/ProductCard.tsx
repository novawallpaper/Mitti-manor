import React from "react";
import { Link } from "react-router-dom";
import { Product } from "../types";

export default function ProductCard({ product }: { product: Product }) {
  return (
    <Link
      to={`/products/${product.slug}`}
      className="bg-white rounded-xl border border-earth-100 overflow-hidden hover:shadow-lg transition-shadow flex flex-col"
    >
      <div className="aspect-square bg-earth-50 overflow-hidden">
        {product.images[0] ? (
          <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-earth-300">No image</div>
        )}
      </div>
      <div className="p-4 flex flex-col gap-1 flex-1">
        {product.category_name && (
          <span className="text-xs uppercase tracking-wide text-earth-400 font-semibold">
            {product.category_name}
          </span>
        )}
        <h3 className="font-semibold text-earth-900 line-clamp-2">{product.name}</h3>
        <div className="mt-auto pt-2 flex items-end justify-between">
          <div>
            <p className="text-lg font-bold text-earth-700">₹{product.wholesale_price.toFixed(2)}</p>
            <p className="text-xs text-earth-400">per {product.unit}</p>
          </div>
          <span className="text-xs bg-earth-100 text-earth-700 px-2 py-1 rounded-md">
            MOQ {product.moq}
          </span>
        </div>
        {product.stock <= 0 && (
          <span className="text-xs text-red-500 font-medium">Out of stock</span>
        )}
      </div>
    </Link>
  );
}
