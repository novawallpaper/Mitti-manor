import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const { cart } = useCart();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <header className="sticky top-0 z-40 bg-earth-900 text-earth-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-16">
        <Link to="/" className="flex items-center gap-2 font-bold text-xl tracking-wide">
          <span className="bg-earth-300 text-earth-900 rounded-lg px-2 py-1">MM</span>
          MITTI MANOR
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <Link to="/" className="hover:text-earth-300">Shop</Link>
          {isAuthenticated && <Link to="/orders" className="hover:text-earth-300">Orders</Link>}
          {isAuthenticated && <Link to="/wishlist" className="hover:text-earth-300">Wishlist</Link>}
          <Link to="/cart" className="hover:text-earth-300 relative">
            Cart
            {cart.total_items > 0 && (
              <span className="absolute -top-2 -right-4 bg-earth-300 text-earth-900 text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {cart.total_items}
              </span>
            )}
          </Link>
          {isAuthenticated ? (
            <>
              <Link to="/profile" className="hover:text-earth-300">Hi, {user?.full_name.split(" ")[0]}</Link>
              <button onClick={handleLogout} className="bg-earth-300 text-earth-900 px-3 py-1.5 rounded-lg hover:bg-earth-200">
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="bg-earth-300 text-earth-900 px-3 py-1.5 rounded-lg hover:bg-earth-200">
              Login
            </Link>
          )}
        </nav>

        <button className="md:hidden" onClick={() => setMenuOpen((o) => !o)} aria-label="Toggle menu">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {menuOpen && (
        <nav className="md:hidden flex flex-col gap-1 px-4 pb-4 text-sm font-medium bg-earth-900">
          <Link to="/" onClick={() => setMenuOpen(false)} className="py-2">Shop</Link>
          {isAuthenticated && <Link to="/orders" onClick={() => setMenuOpen(false)} className="py-2">Orders</Link>}
          {isAuthenticated && <Link to="/wishlist" onClick={() => setMenuOpen(false)} className="py-2">Wishlist</Link>}
          <Link to="/cart" onClick={() => setMenuOpen(false)} className="py-2">Cart ({cart.total_items})</Link>
          {isAuthenticated ? (
            <>
              <Link to="/profile" onClick={() => setMenuOpen(false)} className="py-2">Profile</Link>
              <button onClick={handleLogout} className="text-left py-2">Logout</button>
            </>
          ) : (
            <Link to="/login" onClick={() => setMenuOpen(false)} className="py-2">Login</Link>
          )}
        </nav>
      )}
    </header>
  );
}
