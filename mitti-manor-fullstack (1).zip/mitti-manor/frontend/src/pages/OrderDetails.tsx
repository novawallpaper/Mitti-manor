import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { fetchOrderDetails } from "../api/orders";
import Loader from "../components/Loader";
import { Order } from "../types";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  confirmed: "bg-blue-100 text-blue-700",
  processing: "bg-blue-100 text-blue-700",
  shipped: "bg-purple-100 text-purple-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

export default function OrderDetails() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    fetchOrderDetails(id)
      .then(setOrder)
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <Loader />;
  if (!order) return <p className="text-center py-16 text-earth-500">Order not found.</p>;

  const addr = order.delivery_address;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h1 className="text-2xl font-bold text-earth-900">{order.order_number}</h1>
          <p className="text-earth-500 text-sm">Placed on {new Date(order.created_at).toLocaleString()}</p>
        </div>
        <span className={`text-sm px-3 py-1.5 rounded-full font-medium ${STATUS_COLORS[order.status] || "bg-earth-100 text-earth-700"}`}>
          {order.status}
        </span>
      </div>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Order Status Timeline</h2>
        <ol className="flex flex-col gap-2">
          {order.status_history.map((h, i) => (
            <li key={i} className="flex justify-between text-sm text-earth-600">
              <span className="capitalize">{h.status}</span>
              <span>{new Date(h.at).toLocaleString()}</span>
            </li>
          ))}
        </ol>
      </div>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Delivery Address</h2>
        <p className="text-sm text-earth-600">
          {addr.contact_name} ({addr.contact_mobile})<br />
          {addr.address_line1}{addr.address_line2 ? `, ${addr.address_line2}` : ""}<br />
          {addr.city}, {addr.state} - {addr.pincode}
        </p>
      </div>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Items</h2>
        {order.items.map((item, i) => (
          <div key={i} className="flex justify-between text-sm py-1.5 border-b border-earth-50 last:border-0">
            <span className="text-earth-700">{item.product_name} × {item.quantity}</span>
            <span className="text-earth-800 font-medium">₹{item.line_total.toFixed(2)}</span>
          </div>
        ))}
        <div className="flex justify-between font-bold text-earth-900 pt-3 mt-2 border-t border-earth-100">
          <span>Total</span>
          <span>₹{order.total_amount.toFixed(2)}</span>
        </div>
      </div>

      {order.notes && (
        <div className="bg-white border border-earth-100 rounded-xl p-5">
          <h2 className="font-semibold text-earth-800 mb-2">Notes</h2>
          <p className="text-sm text-earth-600">{order.notes}</p>
        </div>
      )}
    </div>
  );
}
