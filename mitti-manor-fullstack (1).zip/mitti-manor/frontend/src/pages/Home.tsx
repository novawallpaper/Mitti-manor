import React, { useEffect, useState } from "react";
import { fetchCategories, fetchProducts } from "../api/products";
import CategoryFilter from "../components/CategoryFilter";
import Loader from "../components/Loader";
import ProductCard from "../components/ProductCard";
import { Category, Product } from "../types";

export default function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(12);
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<"created_at" | "wholesale_price" | "name">("created_at");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCategories().then(setCategories).catch(() => setCategories([]));
  }, []);

  useEffect(() => {
    setLoading(true);
    fetchProducts({
      search: search || undefined,
      category_id: selectedCategoryId || undefined,
      sort_by: sortBy,
      sort_order: sortBy === "wholesale_price" ? "asc" : "desc",
      page,
      page_size: pageSize,
    })
      .then((res) => {
        setProducts(res.items);
        setTotal(res.total);
      })
      .finally(() => setLoading(false));
  }, [search, selectedCategoryId, sortBy, page, pageSize]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="bg-earth-700 text-earth-50 rounded-2xl p-8 mb-8">
        <h1 className="text-3xl font-bold mb-2">Wholesale disposables for your business</h1>
        <p className="text-earth-100 max-w-2xl">
          Bulk pricing on cutlery, cups, food packaging & more — built for shops, restaurants, cafes and hotels.
        </p>
      </div>

      <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setPage(1);
            setSearch(searchInput);
          }}
          className="flex-1 flex gap-2"
        >
          <input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search products..."
            className="flex-1 border border-earth-200 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400"
          />
          <button type="submit" className="bg-earth-700 text-white px-4 py-2 rounded-lg hover:bg-earth-800">
            Search
          </button>
        </form>

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="border border-earth-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-earth-400"
        >
          <option value="created_at">Newest</option>
          <option value="wholesale_price">Price: Low to High</option>
          <option value="name">Name: A-Z</option>
        </select>
      </div>

      <div className="mb-6">
        <CategoryFilter
          categories={categories}
          selectedCategoryId={selectedCategoryId}
          onSelect={(id) => {
            setSelectedCategoryId(id);
            setPage(1);
          }}
        />
      </div>

      {loading ? (
        <Loader />
      ) : products.length === 0 ? (
        <p className="text-earth-500 text-center py-16">No products found. Try a different search or filter.</p>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-8">
              <button
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1.5 rounded-lg border border-earth-200 disabled:opacity-40"
              >
                Prev
              </button>
              <span className="text-sm text-earth-600">
                Page {page} of {totalPages}
              </span>
              <button
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1.5 rounded-lg border border-earth-200 disabled:opacity-40"
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
