import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";

export default function Cart() {
  const { cart, setItemQuantity, removeItem } = useCart();
  const navigate = useNavigate();

  if (cart.items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-earth-900 mb-2">Your cart is empty</h1>
        <p className="text-earth-500 mb-6">Browse our wholesale catalog and add products in bulk.</p>
        <Link to="/" className="bg-earth-700 text-white px-6 py-2.5 rounded-lg hover:bg-earth-800">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-earth-900 mb-6">Your Cart</h1>

      <div className="flex flex-col gap-4">
        {cart.items.map((item) => (
          <div key={item.product.id} className="flex gap-4 bg-white border border-earth-100 rounded-xl p-4">
            <div className="w-20 h-20 rounded-lg bg-earth-50 overflow-hidden flex-shrink-0">
              {item.product.images[0] && (
                <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover" />
              )}
            </div>
            <div className="flex-1">
              <Link to={`/products/${item.product.slug}`} className="font-semibold text-earth-900 hover:underline">
                {item.product.name}
              </Link>
              <p className="text-sm text-earth-500">₹{item.unit_price_applied.toFixed(2)} / {item.product.unit}</p>
              <div className="flex items-center gap-3 mt-2">
                <input
                  type="number"
                  min={item.product.moq}
                  max={item.product.stock}
                  value={item.quantity}
                  onChange={(e) =>
                    setItemQuantity(item.product.id, Math.max(item.product.moq, Number(e.target.value)))
                  }
                  className="w-20 border border-earth-200 rounded-lg px-2 py-1 text-center text-sm"
                />
                <button
                  onClick={() => removeItem(item.product.id)}
                  className="text-sm text-red-500 hover:underline"
                >
                  Remove
                </button>
              </div>
            </div>
            <div className="text-right font-semibold text-earth-800">₹{item.line_total.toFixed(2)}</div>
          </div>
        ))}
      </div>

      <div className="mt-8 flex justify-end">
        <div className="w-full sm:w-80 bg-white border border-earth-100 rounded-xl p-5">
          <div className="flex justify-between text-earth-600 mb-1">
            <span>Items</span>
            <span>{cart.total_items}</span>
          </div>
          <div className="flex justify-between text-lg font-bold text-earth-900 mb-4">
            <span>Subtotal</span>
            <span>₹{cart.subtotal.toFixed(2)}</span>
          </div>
          <button
            onClick={() => navigate("/checkout")}
            className="w-full bg-earth-700 text-white font-medium py-2.5 rounded-lg hover:bg-earth-800"
          >
            Proceed to Checkout
          </button>
        </div>
      </div>
    </div>
  );
}
