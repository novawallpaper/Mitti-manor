import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { addToWishlist } from "../api/wishlist";
import { apiErrorMessage } from "../api/client";
import { fetchProduct } from "../api/products";
import Loader from "../components/Loader";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { Product } from "../types";

export default function ProductDetails() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { setItemQuantity } = useCart();

  const [product, setProduct] = useState<Product | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    fetchProduct(slug)
      .then((p) => {
        setProduct(p);
        setQuantity(p.moq);
      })
      .catch(() => setProduct(null))
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) return <Loader />;
  if (!product) return <p className="text-center py-16 text-earth-500">Product not found.</p>;

  const applicableTier = [...product.bulk_pricing]
    .sort((a, b) => a.min_qty - b.min_qty)
    .reduce((acc, tier) => (quantity >= tier.min_qty ? tier : acc), null as null | { min_qty: number; price_per_unit: number });
  const unitPrice = applicableTier ? applicableTier.price_per_unit : product.wholesale_price;
  const lineTotal = unitPrice * quantity;

  const handleAddToCart = async () => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    setError(null);
    setMessage(null);
    try {
      await setItemQuantity(product.id, quantity);
      setMessage("Added to cart!");
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  };

  const handleWishlist = async () => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    await addToWishlist(product.id);
    setMessage("Added to wishlist!");
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-2 gap-10">
      <div>
        <div className="aspect-square bg-earth-50 rounded-xl overflow-hidden border border-earth-100">
          {product.images[activeImage] ? (
            <img src={product.images[activeImage]} alt={product.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-earth-300">No image</div>
          )}
        </div>
        {product.images.length > 1 && (
          <div className="flex gap-2 mt-3">
            {product.images.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImage(i)}
                className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${
                  i === activeImage ? "border-earth-600" : "border-transparent"
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      <div>
        {product.category_name && (
          <span className="text-xs uppercase tracking-wide text-earth-400 font-semibold">{product.category_name}</span>
        )}
        <h1 className="text-2xl font-bold text-earth-900 mt-1">{product.name}</h1>
        <p className="text-earth-600 mt-3">{product.description}</p>

        <div className="mt-5 flex items-baseline gap-3">
          <span className="text-3xl font-bold text-earth-700">₹{unitPrice.toFixed(2)}</span>
          <span className="text-earth-400 text-sm">per {product.unit}</span>
        </div>
        <p className="text-sm text-earth-500 mt-1">MOQ: {product.moq} • {product.stock} in stock</p>

        {product.bulk_pricing.length > 0 && (
          <div className="mt-5 border border-earth-100 rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-earth-50 text-earth-600">
                <tr>
                  <th className="text-left px-3 py-2">Quantity</th>
                  <th className="text-left px-3 py-2">Price / unit</th>
                </tr>
              </thead>
              <tbody>
                {[...product.bulk_pricing]
                  .sort((a, b) => a.min_qty - b.min_qty)
                  .map((tier, i) => (
                    <tr key={i} className="border-t border-earth-100">
                      <td className="px-3 py-2">{tier.min_qty}+ units</td>
                      <td className="px-3 py-2">₹{tier.price_per_unit.toFixed(2)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}

        {Object.keys(product.specifications).length > 0 && (
          <div className="mt-5">
            <h2 className="font-semibold text-earth-800 mb-2">Specifications</h2>
            <dl className="grid grid-cols-2 gap-y-1 text-sm">
              {Object.entries(product.specifications).map(([k, v]) => (
                <React.Fragment key={k}>
                  <dt className="text-earth-500">{k}</dt>
                  <dd className="text-earth-800">{v}</dd>
                </React.Fragment>
              ))}
            </dl>
          </div>
        )}

        <div className="mt-6 flex items-center gap-3">
          <input
            type="number"
            min={product.moq}
            max={product.stock}
            value={quantity}
            onChange={(e) => setQuantity(Math.max(product.moq, Number(e.target.value)))}
            className="w-24 border border-earth-200 rounded-lg px-3 py-2 text-center focus:outline-none focus:ring-2 focus:ring-earth-400"
          />
          <span className="text-earth-500 text-sm">Line total: ₹{lineTotal.toFixed(2)}</span>
        </div>

        {error && <p className="text-sm text-red-600 mt-2">{error}</p>}
        {message && <p className="text-sm text-green-600 mt-2">{message}</p>}

        <div className="mt-4 flex gap-3">
          <button
            onClick={handleAddToCart}
            disabled={product.stock <= 0}
            className="bg-earth-700 text-white font-medium px-6 py-2.5 rounded-lg hover:bg-earth-800 disabled:opacity-50"
          >
            {product.stock <= 0 ? "Out of stock" : "Add to Cart"}
          </button>
          <button
            onClick={handleWishlist}
            className="border border-earth-300 text-earth-700 font-medium px-6 py-2.5 rounded-lg hover:bg-earth-50"
          >
            ♡ Wishlist
          </button>
        </div>
      </div>
    </div>
  );
}
