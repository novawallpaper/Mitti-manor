import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchMyOrders } from "../api/orders";
import Loader from "../components/Loader";
import { Order } from "../types";

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-yellow-100 text-yellow-700",
  confirmed: "bg-blue-100 text-blue-700",
  processing: "bg-blue-100 text-blue-700",
  shipped: "bg-purple-100 text-purple-700",
  delivered: "bg-green-100 text-green-700",
  cancelled: "bg-red-100 text-red-700",
};

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMyOrders()
      .then(setOrders)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loader />;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-earth-900 mb-6">Your Orders</h1>

      {orders.length === 0 ? (
        <p className="text-earth-500 text-center py-16">You haven't placed any orders yet.</p>
      ) : (
        <div className="flex flex-col gap-4">
          {orders.map((order) => (
            <Link
              key={order.id}
              to={`/orders/${order.id}`}
              className="bg-white border border-earth-100 rounded-xl p-5 flex justify-between items-center hover:shadow-md transition-shadow"
            >
              <div>
                <p className="font-semibold text-earth-900">{order.order_number}</p>
                <p className="text-sm text-earth-500">
                  {new Date(order.created_at).toLocaleDateString()} • {order.total_items} items
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-earth-800">₹{order.total_amount.toFixed(2)}</p>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_COLORS[order.status] || "bg-earth-100 text-earth-700"}`}>
                  {order.status}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
