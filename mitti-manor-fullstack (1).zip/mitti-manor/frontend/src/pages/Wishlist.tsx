import React, { useEffect, useState } from "react";
import { fetchWishlist, removeFromWishlist } from "../api/wishlist";
import Loader from "../components/Loader";
import ProductCard from "../components/ProductCard";
import { WishlistEntry } from "../types";

export default function Wishlist() {
  const [entries, setEntries] = useState<WishlistEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    fetchWishlist()
      .then(setEntries)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, []);

  const handleRemove = async (productId: string) => {
    await removeFromWishlist(productId);
    load();
  };

  if (loading) return <Loader />;

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-earth-900 mb-6">Your Wishlist</h1>

      {entries.length === 0 ? (
        <p className="text-earth-500 text-center py-16">Your wishlist is empty.</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {entries.map((entry) => (
            <div key={entry.id} className="relative">
              <ProductCard product={entry.product} />
              <button
                onClick={() => handleRemove(entry.product.id)}
                className="absolute top-2 right-2 bg-white/90 text-red-500 text-xs px-2 py-1 rounded-md shadow hover:bg-white"
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
