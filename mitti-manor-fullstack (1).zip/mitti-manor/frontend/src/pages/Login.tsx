import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { apiErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const from = (location.state as any)?.from?.pathname || "/";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(identifier, password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 bg-white border border-earth-100 rounded-xl p-8 shadow-sm">
      <h1 className="text-2xl font-bold text-earth-900 mb-1">Welcome back</h1>
      <p className="text-earth-500 mb-6">Login to your MITTI MANOR wholesale account</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="block text-sm font-medium text-earth-700 mb-1">Mobile or Email</label>
          <input
            type="text"
            required
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            className="w-full border border-earth-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400"
            placeholder="9876543210 or you@business.com"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-earth-700 mb-1">Password</label>
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full border border-earth-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400"
            placeholder="••••••••"
          />
        </div>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="bg-earth-700 text-white font-medium py-2.5 rounded-lg hover:bg-earth-800 disabled:opacity-60"
        >
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>

      <p className="text-sm text-earth-500 mt-6 text-center">
        Don't have an account?{" "}
        <Link to="/register" className="text-earth-700 font-semibold hover:underline">
          Register your business
        </Link>
      </p>
    </div>
  );
}
