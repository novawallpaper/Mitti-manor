import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { sendOtp, verifyOtp } from "../api/auth";
import { apiErrorMessage } from "../api/client";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({ full_name: "", mobile: "", email: "", password: "" });
  const [step, setStep] = useState<"details" | "otp">("details");
  const [otp, setOtp] = useState("");
  const [demoOtpHint, setDemoOtpHint] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const update = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await sendOtp(form.mobile);
      setDemoOtpHint(res.demo_otp_code); // DEMO MODE ONLY — a real SMS integration would not do this
      setStep("otp");
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyAndRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await verifyOtp(form.mobile, otp);
      await register({
        full_name: form.full_name,
        mobile: form.mobile,
        email: form.email || undefined,
        password: form.password,
      });
      navigate("/", { replace: true });
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto mt-12 bg-white border border-earth-100 rounded-xl p-8 shadow-sm">
      <h1 className="text-2xl font-bold text-earth-900 mb-1">Create your account</h1>
      <p className="text-earth-500 mb-6">Register your shop, restaurant, cafe or hotel for wholesale pricing.</p>

      {step === "details" && (
        <form onSubmit={handleSendOtp} className="flex flex-col gap-4">
          <div>
            <label className="block text-sm font-medium text-earth-700 mb-1">Full Name</label>
            <input required value={form.full_name} onChange={update("full_name")}
              className="w-full border border-earth-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-earth-700 mb-1">Mobile Number</label>
            <input required value={form.mobile} onChange={update("mobile")}
              placeholder="9876543210"
              className="w-full border border-earth-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-earth-700 mb-1">Email (optional)</label>
            <input type="email" value={form.email} onChange={update("email")}
              className="w-full border border-earth-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-earth-700 mb-1">Password</label>
            <input type="password" required minLength={6} value={form.password} onChange={update("password")}
              className="w-full border border-earth-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-earth-400" />
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={loading}
            className="bg-earth-700 text-white font-medium py-2.5 rounded-lg hover:bg-earth-800 disabled:opacity-60">
            {loading ? "Sending OTP..." : "Send OTP"}
          </button>
        </form>
      )}

      {step === "otp" && (
        <form onSubmit={handleVerifyAndRegister} className="flex flex-col gap-4">
          <p className="text-sm text-earth-600">
            Enter the OTP sent to <strong>{form.mobile}</strong>.
          </p>
          {demoOtpHint && (
            <div className="text-xs bg-earth-100 text-earth-700 rounded-lg px-3 py-2">
              Demo mode — no real SMS is sent. Your OTP is <strong>{demoOtpHint}</strong>.
            </div>
          )}
          <input required value={otp} onChange={(e) => setOtp(e.target.value)} maxLength={6}
            placeholder="6-digit OTP"
            className="w-full border border-earth-200 rounded-lg px-3 py-2 tracking-widest text-center text-lg focus:outline-none focus:ring-2 focus:ring-earth-400" />

          {error && <p className="text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={loading}
            className="bg-earth-700 text-white font-medium py-2.5 rounded-lg hover:bg-earth-800 disabled:opacity-60">
            {loading ? "Verifying..." : "Verify & Create Account"}
          </button>
          <button type="button" onClick={() => setStep("details")} className="text-sm text-earth-500 hover:underline">
            ← Edit details
          </button>
        </form>
      )}

      <p className="text-sm text-earth-500 mt-6 text-center">
        Already have an account?{" "}
        <Link to="/login" className="text-earth-700 font-semibold hover:underline">Login</Link>
      </p>
    </div>
  );
}
