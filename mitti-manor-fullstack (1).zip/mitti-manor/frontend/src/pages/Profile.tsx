import React, { useEffect, useState } from "react";
import { fetchMyBusiness, upsertMyBusiness } from "../api/business";
import { apiErrorMessage } from "../api/client";
import Loader from "../components/Loader";
import { useAuth } from "../context/AuthContext";
import { Business } from "../types";

const BUSINESS_TYPES = ["Restaurant", "Cafe", "Hotel", "Retail Shop", "Caterer", "Other"];

const emptyBusiness = {
  owner_name: "",
  business_name: "",
  mobile: "",
  business_type: BUSINESS_TYPES[0],
  gstin: "",
  address: "",
  city: "",
  state: "",
  pincode: "",
};

export default function Profile() {
  const { user } = useAuth();
  const [business, setBusiness] = useState<Business | null>(null);
  const [form, setForm] = useState(emptyBusiness);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchMyBusiness()
      .then((b) => {
        if (b) {
          setBusiness(b);
          setForm({
            owner_name: b.owner_name,
            business_name: b.business_name,
            mobile: b.mobile,
            business_type: b.business_type,
            gstin: b.gstin || "",
            address: b.address,
            city: b.city,
            state: b.state,
            pincode: b.pincode,
          });
        } else if (user) {
          setForm((f) => ({ ...f, owner_name: user.full_name, mobile: user.mobile }));
        }
      })
      .finally(() => setLoading(false));
  }, [user]);

  const update = (field: keyof typeof emptyBusiness) => (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setSaving(true);
    try {
      const saved = await upsertMyBusiness(form);
      setBusiness(saved);
      setMessage("Business profile saved.");
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-earth-900 mb-6">Your Profile</h1>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Account</h2>
        <p className="text-sm text-earth-600">Name: {user?.full_name}</p>
        <p className="text-sm text-earth-600">Mobile: {user?.mobile}</p>
        {user?.email && <p className="text-sm text-earth-600">Email: {user.email}</p>}
      </div>

      <div className="bg-white border border-earth-100 rounded-xl p-5">
        <h2 className="font-semibold text-earth-800 mb-3">
          {business ? "Business Profile" : "Complete your Business Profile"}
        </h2>
        <form onSubmit={handleSave} className="grid sm:grid-cols-2 gap-3">
          <input placeholder="Owner Name" required value={form.owner_name} onChange={update("owner_name")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Business / Shop Name" required value={form.business_name} onChange={update("business_name")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Mobile Number" required value={form.mobile} onChange={update("mobile")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
          <select value={form.business_type} onChange={update("business_type")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm">
            {BUSINESS_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <input placeholder="GSTIN (optional)" value={form.gstin} onChange={update("gstin")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
          <input placeholder="Business Address" required value={form.address} onChange={update("address")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
          <input placeholder="City" required value={form.city} onChange={update("city")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="State" required value={form.state} onChange={update("state")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
          <input placeholder="Pincode" required value={form.pincode} onChange={update("pincode")}
            className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />

          {error && <p className="text-sm text-red-600 sm:col-span-2">{error}</p>}
          {message && <p className="text-sm text-green-600 sm:col-span-2">{message}</p>}

          <button type="submit" disabled={saving}
            className="sm:col-span-2 bg-earth-700 text-white font-medium py-2.5 rounded-lg hover:bg-earth-800 disabled:opacity-60">
            {saving ? "Saving..." : "Save Business Profile"}
          </button>
        </form>
      </div>
    </div>
  );
}
