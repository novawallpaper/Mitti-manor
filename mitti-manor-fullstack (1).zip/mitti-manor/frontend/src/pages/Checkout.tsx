import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchAddresses } from "../api/addresses";
import { apiErrorMessage } from "../api/client";
import { checkout } from "../api/orders";
import Loader from "../components/Loader";
import { useCart } from "../context/CartContext";
import { Address } from "../types";

const emptyNewAddress = {
  label: "Shop",
  contact_name: "",
  contact_mobile: "",
  address_line1: "",
  address_line2: "",
  city: "",
  state: "",
  pincode: "",
  is_default: false,
};

export default function Checkout() {
  const { cart, refreshCart } = useCart();
  const navigate = useNavigate();

  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(null);
  const [useNewAddress, setUseNewAddress] = useState(false);
  const [newAddress, setNewAddress] = useState(emptyNewAddress);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAddresses()
      .then((addrs) => {
        setAddresses(addrs);
        const def = addrs.find((a) => a.is_default) || addrs[0];
        if (def) setSelectedAddressId(def.id);
        else setUseNewAddress(true);
      })
      .finally(() => setLoading(false));
  }, []);

  const updateNewAddress = (field: keyof typeof emptyNewAddress) => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => setNewAddress((a) => ({ ...a, [field]: e.target.value }));

  const handlePlaceOrder = async () => {
    setError(null);
    setPlacing(true);
    try {
      const order = await checkout({
        address_id: useNewAddress ? undefined : selectedAddressId || undefined,
        new_address: useNewAddress ? newAddress : undefined,
        notes: notes || undefined,
      });
      await refreshCart();
      navigate(`/orders/${order.id}`, { replace: true });
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setPlacing(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-earth-900 mb-6">Checkout</h1>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Delivery Address</h2>

        {addresses.length > 0 && !useNewAddress && (
          <div className="flex flex-col gap-2 mb-3">
            {addresses.map((addr) => (
              <label
                key={addr.id}
                className={`flex gap-3 border rounded-lg p-3 cursor-pointer ${
                  selectedAddressId === addr.id ? "border-earth-600 bg-earth-50" : "border-earth-200"
                }`}
              >
                <input
                  type="radio"
                  name="address"
                  checked={selectedAddressId === addr.id}
                  onChange={() => setSelectedAddressId(addr.id)}
                  className="mt-1"
                />
                <div className="text-sm">
                  <p className="font-medium text-earth-900">{addr.label} — {addr.contact_name} ({addr.contact_mobile})</p>
                  <p className="text-earth-500">
                    {addr.address_line1}, {addr.address_line2 ? `${addr.address_line2}, ` : ""}
                    {addr.city}, {addr.state} - {addr.pincode}
                  </p>
                </div>
              </label>
            ))}
          </div>
        )}

        <button
          onClick={() => setUseNewAddress((v) => !v)}
          className="text-sm text-earth-700 font-medium hover:underline"
        >
          {useNewAddress ? "← Use a saved address" : "+ Add a new address"}
        </button>

        {useNewAddress && (
          <div className="grid sm:grid-cols-2 gap-3 mt-4">
            <input placeholder="Label (e.g. Shop)" value={newAddress.label} onChange={updateNewAddress("label")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
            <input placeholder="Contact Name" required value={newAddress.contact_name} onChange={updateNewAddress("contact_name")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
            <input placeholder="Contact Mobile" required value={newAddress.contact_mobile} onChange={updateNewAddress("contact_mobile")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
            <input placeholder="Address Line 1" required value={newAddress.address_line1} onChange={updateNewAddress("address_line1")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
            <input placeholder="Address Line 2 (optional)" value={newAddress.address_line2} onChange={updateNewAddress("address_line2")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm sm:col-span-2" />
            <input placeholder="City" required value={newAddress.city} onChange={updateNewAddress("city")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
            <input placeholder="State" required value={newAddress.state} onChange={updateNewAddress("state")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
            <input placeholder="Pincode" required value={newAddress.pincode} onChange={updateNewAddress("pincode")}
              className="border border-earth-200 rounded-lg px-3 py-2 text-sm" />
          </div>
        )}
      </div>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Order Notes (optional)</h2>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="Delivery instructions, preferred time, etc."
          className="w-full border border-earth-200 rounded-lg px-3 py-2 text-sm"
        />
      </div>

      <div className="bg-white border border-earth-100 rounded-xl p-5 mb-6">
        <h2 className="font-semibold text-earth-800 mb-3">Order Summary</h2>
        {cart.items.map((item) => (
          <div key={item.product.id} className="flex justify-between text-sm py-1 text-earth-600">
            <span>{item.product.name} × {item.quantity}</span>
            <span>₹{item.line_total.toFixed(2)}</span>
          </div>
        ))}
        <div className="flex justify-between font-bold text-earth-900 pt-3 mt-2 border-t border-earth-100">
          <span>Total</span>
          <span>₹{cart.subtotal.toFixed(2)}</span>
        </div>
      </div>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <button
        onClick={handlePlaceOrder}
        disabled={placing || cart.items.length === 0}
        className="w-full bg-earth-700 text-white font-medium py-3 rounded-lg hover:bg-earth-800 disabled:opacity-60"
      >
        {placing ? "Placing order..." : "Place Order"}
      </button>
    </div>
  );
}
