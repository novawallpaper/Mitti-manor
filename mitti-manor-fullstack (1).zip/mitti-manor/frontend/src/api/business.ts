import { apiClient } from "./client";
import { Business } from "../types";

export async function fetchMyBusiness(): Promise<Business | null> {
  try {
    const res = await apiClient.get<Business>("/api/business/me");
    return res.data;
  } catch (err: any) {
    if (err.response?.status === 404) return null;
    throw err;
  }
}

export async function upsertMyBusiness(
  data: Omit<Business, "id" | "user_id" | "created_at" | "updated_at">
): Promise<Business> {
  const res = await apiClient.put<Business>("/api/business/me", data);
  return res.data;
}
