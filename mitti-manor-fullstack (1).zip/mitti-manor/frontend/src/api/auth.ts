import { apiClient } from "./client";
import { User } from "../types";

export interface TokenResponse {
  access_token: string;
  token_type: string;
  user: User;
}

export async function registerUser(data: {
  full_name: string;
  mobile: string;
  email?: string;
  password: string;
}): Promise<TokenResponse> {
  const res = await apiClient.post<TokenResponse>("/api/auth/register", data);
  return res.data;
}

export async function loginUser(data: {
  identifier: string;
  password: string;
}): Promise<TokenResponse> {
  const res = await apiClient.post<TokenResponse>("/api/auth/login", data);
  return res.data;
}

export async function sendOtp(mobile: string): Promise<{ message: string; demo_otp_code: string }> {
  const res = await apiClient.post("/api/auth/otp/send", { mobile });
  return res.data;
}

export async function verifyOtp(mobile: string, otp_code: string): Promise<{ message: string }> {
  const res = await apiClient.post("/api/auth/otp/verify", { mobile, otp_code });
  return res.data;
}

export async function getCurrentUser(): Promise<User> {
  const res = await apiClient.get<User>("/api/auth/me");
  return res.data;
}

export async function logoutUser(): Promise<void> {
  await apiClient.post("/api/auth/logout");
}
