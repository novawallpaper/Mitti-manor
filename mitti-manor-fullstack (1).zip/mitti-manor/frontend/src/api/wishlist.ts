import { apiClient } from "./client";
import { WishlistEntry } from "../types";

export async function fetchWishlist(): Promise<WishlistEntry[]> {
  const res = await apiClient.get<WishlistEntry[]>("/api/wishlist");
  return res.data;
}

export async function addToWishlist(productId: string): Promise<void> {
  await apiClient.post(`/api/wishlist/${productId}`);
}

export async function removeFromWishlist(productId: string): Promise<void> {
  await apiClient.delete(`/api/wishlist/${productId}`);
}
