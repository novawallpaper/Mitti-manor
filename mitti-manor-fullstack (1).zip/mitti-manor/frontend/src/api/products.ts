import { apiClient } from "./client";
import { Category, Product, ProductListResponse } from "../types";

export interface ProductQueryParams {
  search?: string;
  category_id?: string;
  min_price?: number;
  max_price?: number;
  sort_by?: "created_at" | "wholesale_price" | "name";
  sort_order?: "asc" | "desc";
  page?: number;
  page_size?: number;
}

export async function fetchProducts(params: ProductQueryParams = {}): Promise<ProductListResponse> {
  const res = await apiClient.get<ProductListResponse>("/api/products", { params });
  return res.data;
}

export async function fetchProduct(idOrSlug: string): Promise<Product> {
  const res = await apiClient.get<Product>(`/api/products/${idOrSlug}`);
  return res.data;
}

export async function fetchCategories(): Promise<Category[]> {
  const res = await apiClient.get<Category[]>("/api/categories");
  return res.data;
}
