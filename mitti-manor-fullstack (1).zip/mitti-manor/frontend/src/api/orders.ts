import { apiClient } from "./client";
import { Order } from "../types";

export interface CheckoutPayload {
  address_id?: string;
  new_address?: {
    label: string;
    contact_name: string;
    contact_mobile: string;
    address_line1: string;
    address_line2?: string;
    city: string;
    state: string;
    pincode: string;
    is_default: boolean;
  };
  notes?: string;
}

export async function checkout(payload: CheckoutPayload): Promise<Order> {
  const res = await apiClient.post<Order>("/api/orders/checkout", payload);
  return res.data;
}

export async function fetchMyOrders(): Promise<Order[]> {
  const res = await apiClient.get<Order[]>("/api/orders");
  return res.data;
}

export async function fetchOrderDetails(id: string): Promise<Order> {
  const res = await apiClient.get<Order>(`/api/orders/${id}`);
  return res.data;
}
