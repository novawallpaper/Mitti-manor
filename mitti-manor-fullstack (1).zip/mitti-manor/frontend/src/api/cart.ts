import { apiClient } from "./client";
import { Cart } from "../types";

export async function fetchCart(): Promise<Cart> {
  const res = await apiClient.get<Cart>("/api/cart");
  return res.data;
}

export async function upsertCartItem(product_id: string, quantity: number): Promise<Cart> {
  const res = await apiClient.post<Cart>("/api/cart/items", { product_id, quantity });
  return res.data;
}

export async function removeCartItem(product_id: string): Promise<Cart> {
  const res = await apiClient.delete<Cart>(`/api/cart/items/${product_id}`);
  return res.data;
}

export async function clearCart(): Promise<Cart> {
  const res = await apiClient.delete<Cart>("/api/cart");
  return res.data;
}
