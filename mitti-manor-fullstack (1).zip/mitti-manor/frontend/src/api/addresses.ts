import { apiClient } from "./client";
import { Address } from "../types";

export async function fetchAddresses(): Promise<Address[]> {
  const res = await apiClient.get<Address[]>("/api/addresses");
  return res.data;
}

export async function createAddress(data: Omit<Address, "id" | "user_id" | "created_at">): Promise<Address> {
  const res = await apiClient.post<Address>("/api/addresses", data);
  return res.data;
}

export async function deleteAddress(id: string): Promise<void> {
  await apiClient.delete(`/api/addresses/${id}`);
}
