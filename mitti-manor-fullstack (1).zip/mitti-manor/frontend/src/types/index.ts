export interface User {
  id: string;
  full_name: string;
  mobile: string;
  email?: string | null;
  role: "customer" | "admin";
  is_mobile_verified: boolean;
  is_active: boolean;
  created_at: string;
}

export interface Business {
  id: string;
  user_id: string;
  owner_name: string;
  business_name: string;
  mobile: string;
  business_type: string;
  gstin?: string | null;
  address: string;
  city: string;
  state: string;
  pincode: string;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  image_url?: string | null;
  is_active: boolean;
  created_at: string;
}

export interface BulkPricingTier {
  min_qty: number;
  price_per_unit: number;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  category_id: string;
  category_name?: string | null;
  description: string;
  specifications: Record<string, string>;
  images: string[];
  unit: string;
  wholesale_price: number;
  moq: number;
  stock: number;
  bulk_pricing: BulkPricingTier[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ProductListResponse {
  items: Product[];
  total: number;
  page: number;
  page_size: number;
}

export interface Address {
  id: string;
  user_id: string;
  label: string;
  contact_name: string;
  contact_mobile: string;
  address_line1: string;
  address_line2?: string | null;
  city: string;
  state: string;
  pincode: string;
  is_default: boolean;
  created_at: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  unit_price_applied: number;
  line_total: number;
}

export interface Cart {
  items: CartItem[];
  subtotal: number;
  total_items: number;
}

export interface WishlistEntry {
  id: string;
  product: Product;
}

export interface OrderItem {
  product_id: string;
  product_name: string;
  unit_price: number;
  quantity: number;
  line_total: number;
}

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "processing"
  | "shipped"
  | "delivered"
  | "cancelled";

export interface Order {
  id: string;
  order_number: string;
  user_id: string;
  delivery_address: Record<string, any>;
  items: OrderItem[];
  items_subtotal: number;
  total_amount: number;
  total_items: number;
  status: OrderStatus;
  status_history: { status: string; at: string }[];
  notes?: string | null;
  created_at: string;
  updated_at: string;
}
