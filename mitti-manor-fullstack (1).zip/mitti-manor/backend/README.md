# MITTI MANOR — Backend (FastAPI + MongoDB)

## Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # edit values as needed (or use Replit/Bolt Secrets)
```

You need a MongoDB instance. Easiest options:
- **MongoDB Atlas** (free tier): create a cluster, get the connection string, set it as `MONGO_URI` in `.env`.
- **Local MongoDB**: `MONGO_URI=mongodb://localhost:27017`

## Seed demo data

```bash
python seed_db.py
```

This creates demo categories/products and a demo admin account:
- Mobile: `9999999999`
- Password: `admin123`

## Run the API

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

- API base URL: `http://localhost:8000`
- Interactive docs (Swagger): `http://localhost:8000/docs`
- Health check: `http://localhost:8000/api/health`

## Folder structure

```
backend/
  app/
    core/        # settings/config (reads from .env)
    database/    # MongoDB connection (Motor async client)
    auth/        # password hashing, JWT, demo OTP, route-protection deps
    models/      # documented shape of each MongoDB collection
    schemas/     # Pydantic request/response validation
    routes/      # API endpoints, grouped by resource
    services/    # business logic (pricing, order numbers, demo data seeding)
    main.py      # FastAPI app entrypoint
  seed_db.py
  requirements.txt
  .env.example
```

## Authentication

- `POST /api/auth/register` — create an account (full name, mobile, email, password)
- `POST /api/auth/login` — login with mobile or email + password, returns a JWT
- `POST /api/auth/otp/send` — DEMO: generates an OTP (no SMS sent), returned in the response
- `POST /api/auth/otp/verify` — verify a mobile number with the OTP
- `GET /api/auth/me` — current user (requires `Authorization: Bearer <token>`)

Pass the JWT on every protected request:
```
Authorization: Bearer <access_token>
```

## Admin-ready

Every collection and route was designed so an admin dashboard can be added
later without restructuring:
- Users have a `role` field (`"customer"` | `"admin"`).
- `app/auth/deps.py` has `get_current_active_admin` — a dependency any
  future admin route can use.
- Product/category CRUD and order-status-update endpoints already exist
  under admin-protected routes (`POST/PUT/DELETE /api/products`,
  `POST/DELETE /api/categories`, `GET /api/orders/admin/all`,
  `PUT /api/orders/admin/{id}/status`) — just build the admin frontend
  against them.

## Replacing demo OTP with a real SMS provider

All OTP logic lives in `app/auth/otp.py` behind two functions:
`send_otp(mobile)` and `verify_otp(mobile, code)`. Replace their internals
with a call to Twilio/MSG91/AWS SNS/etc. — no other file needs to change.

## Adding a payment gateway later

Orders are created with `total_amount` and `status: "pending"` and no
payment step. To add Razorpay/Stripe/etc. later: create a `payments`
collection, add a payment-initiation route that runs before/after
`/api/orders/checkout`, and update order status on the provider's webhook.
Nothing in the existing schema needs to change.
