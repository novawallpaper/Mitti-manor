"""
`orders` and `order_items` collections.

orders:
{
    "_id": ObjectId,
    "order_number": str,          # unique, human-readable e.g. "MM-20260823-0001"
    "user_id": ObjectId,          # -> users._id
    "delivery_address": dict,     # snapshot of the address at order time
    "items_subtotal": float,
    "total_amount": float,
    "total_items": int,
    "status": str,                # "pending" | "confirmed" | "processing" |
                                   # "shipped" | "delivered" | "cancelled"
    "status_history": list[{"status": str, "at": datetime}],
    "notes": str | None,
    "created_at": datetime,
    "updated_at": datetime,
}

order_items (kept as its own collection so an order's line items can be
queried/reported independently, e.g. best-selling products):
{
    "_id": ObjectId,
    "order_id": ObjectId,     # -> orders._id
    "product_id": ObjectId,   # -> products._id
    "product_name": str,      # snapshot in case product changes later
    "unit_price": float,      # price actually charged (after bulk pricing)
    "quantity": int,
    "line_total": float,
}
"""
