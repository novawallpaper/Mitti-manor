"""
`users` collection.

Relationships:
- businesses.user_id  -> users._id  (one-to-one, a user has one business profile)
- addresses.user_id   -> users._id  (one-to-many)
- orders.user_id      -> users._id  (one-to-many)
- wishlists.user_id   -> users._id  (one-to-many)
- carts.user_id       -> users._id  (one-to-one)

Document shape (for reference — Mongo is schema-less, this is the contract
our code enforces via the schemas in app/schemas/):

{
    "_id": ObjectId,
    "full_name": str,
    "mobile": str,              # unique, used for login/OTP
    "email": str | None,        # unique if present
    "hashed_password": str,
    "role": "customer" | "admin",   # admin-ready
    "is_mobile_verified": bool,
    "is_active": bool,
    "created_at": datetime,
    "updated_at": datetime,
}
"""
