"""
`wishlists` collection.

{
    "_id": ObjectId,
    "user_id": ObjectId,     # -> users._id
    "product_id": ObjectId,  # -> products._id
    "created_at": datetime,
}
(unique compound index on user_id + product_id)

`carts` collection (one active cart per user):
{
    "_id": ObjectId,
    "user_id": ObjectId,   # -> users._id, unique
    "items": list[{
        "product_id": ObjectId,
        "quantity": int,
    }],
    "updated_at": datetime,
}
"""
