"""
`businesses` collection — the B2B profile attached to a user account.

{
    "_id": ObjectId,
    "user_id": ObjectId,        # -> users._id (unique, 1:1)
    "owner_name": str,
    "business_name": str,
    "mobile": str,
    "business_type": str,       # e.g. "Restaurant", "Retail Shop", "Hotel", "Cafe"
    "gstin": str | None,
    "address": str,
    "city": str,
    "state": str,
    "pincode": str,
    "created_at": datetime,
    "updated_at": datetime,
}
"""
