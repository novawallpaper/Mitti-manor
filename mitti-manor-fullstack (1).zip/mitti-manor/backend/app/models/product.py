"""
`products` collection.

Relationships:
- category_id -> categories._id

{
    "_id": ObjectId,
    "name": str,
    "slug": str,                       # unique
    "category_id": ObjectId,
    "description": str,
    "specifications": dict[str, str],  # e.g. {"Material": "Bagasse", "Pack Size": "100 pcs"}
    "images": list[str],               # URLs
    "unit": str,                       # e.g. "carton", "pack", "case"
    "wholesale_price": float,          # per-unit base price
    "moq": int,                        # minimum order quantity (units)
    "stock": int,                      # available units
    "bulk_pricing": list[{             # quantity breakpoints for tiered pricing
        "min_qty": int,
        "price_per_unit": float,
    }],
    "is_active": bool,
    "created_at": datetime,
    "updated_at": datetime,
}
"""
