"""
`addresses` collection — delivery addresses saved by a user.

{
    "_id": ObjectId,
    "user_id": ObjectId,      # -> users._id
    "label": str,             # e.g. "Shop", "Warehouse"
    "contact_name": str,
    "contact_mobile": str,
    "address_line1": str,
    "address_line2": str | None,
    "city": str,
    "state": str,
    "pincode": str,
    "is_default": bool,
    "created_at": datetime,
}
"""
