"""
`categories` collection.

{
    "_id": ObjectId,
    "name": str,
    "slug": str,             # unique, url-friendly
    "description": str | None,
    "image_url": str | None,
    "is_active": bool,
    "created_at": datetime,
}
"""
