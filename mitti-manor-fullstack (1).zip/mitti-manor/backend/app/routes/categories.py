import re
from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_active_admin
from app.database.mongodb import get_database
from app.schemas.category import CategoryCreateRequest, CategoryOut

router = APIRouter(prefix="/api/categories", tags=["Categories"])


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


@router.get("", response_model=list[CategoryOut])
async def list_categories(db: AsyncIOMotorDatabase = Depends(get_database)):
    cursor = db.categories.find({"is_active": True}).sort("name", 1)
    categories = await cursor.to_list(length=200)
    return [CategoryOut(id=c["_id"], **{k: v for k, v in c.items() if k != "_id"}) for c in categories]


# ---- Admin-ready CRUD (protected; requires role == "admin") ----

@router.post("", response_model=CategoryOut, status_code=201)
async def create_category(
    payload: CategoryCreateRequest,
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    slug = slugify(payload.name)
    if await db.categories.find_one({"slug": slug}):
        raise HTTPException(status_code=400, detail="A category with this name already exists")

    doc = {**payload.model_dump(), "slug": slug, "is_active": True, "created_at": datetime.now(timezone.utc)}
    result = await db.categories.insert_one(doc)
    doc["_id"] = result.inserted_id
    return CategoryOut(id=doc["_id"], **{k: v for k, v in doc.items() if k != "_id"})


@router.delete("/{category_id}", status_code=204)
async def delete_category(
    category_id: str,
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    await db.categories.update_one({"_id": ObjectId(category_id)}, {"$set": {"is_active": False}})
