from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_user
from app.auth.otp import send_otp, verify_otp
from app.auth.security import create_access_token, hash_password, verify_password
from app.database.mongodb import get_database
from app.schemas.auth import (
    LoginRequest,
    RegisterRequest,
    SendOtpRequest,
    SendOtpResponse,
    TokenResponse,
    VerifyOtpRequest,
)
from app.schemas.user import UserOut

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


def _serialize_user(user: dict) -> dict:
    return UserOut(id=user["_id"], **{k: v for k, v in user.items() if k != "_id"}).model_dump(mode="json")


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db: AsyncIOMotorDatabase = Depends(get_database)):
    existing = await db.users.find_one(
        {"$or": [{"mobile": payload.mobile}, *([{"email": payload.email}] if payload.email else [])]}
    )
    if existing:
        raise HTTPException(status_code=400, detail="An account with this mobile number or email already exists")

    now = datetime.now(timezone.utc)
    user_doc = {
        "full_name": payload.full_name,
        "mobile": payload.mobile,
        "email": payload.email,
        "hashed_password": hash_password(payload.password),
        "role": "customer",
        "is_mobile_verified": False,
        "is_active": True,
        "created_at": now,
        "updated_at": now,
    }
    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id

    token = create_access_token(subject=str(result.inserted_id))
    return TokenResponse(access_token=token, user=_serialize_user(user_doc))


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, db: AsyncIOMotorDatabase = Depends(get_database)):
    user = await db.users.find_one(
        {"$or": [{"mobile": payload.identifier}, {"email": payload.identifier}]}
    )
    if not user or not verify_password(payload.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is disabled")

    token = create_access_token(subject=str(user["_id"]))
    return TokenResponse(access_token=token, user=_serialize_user(user))


@router.post("/otp/send", response_model=SendOtpResponse)
async def request_otp(payload: SendOtpRequest):
    """
    DEMO MODE: no real SMS is sent. The code is returned in the response
    so the frontend can show it during development. Swap the internals of
    app/auth/otp.py for a real provider before production — this route
    won't need to change.
    """
    code = send_otp(payload.mobile)
    return SendOtpResponse(message="OTP generated (demo mode - no SMS sent)", demo_otp_code=code)


@router.post("/otp/verify")
async def confirm_otp(payload: VerifyOtpRequest, db: AsyncIOMotorDatabase = Depends(get_database)):
    if not verify_otp(payload.mobile, payload.otp_code):
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    await db.users.update_one({"mobile": payload.mobile}, {"$set": {"is_mobile_verified": True}})
    return {"message": "Mobile number verified"}


@router.get("/me", response_model=UserOut)
async def get_me(current_user: dict = Depends(get_current_user)):
    return _serialize_user(current_user)


@router.post("/logout")
async def logout():
    """
    JWTs are stateless, so logout is handled by the frontend discarding
    the token. This endpoint exists for a consistent API contract and as
    a place to add token-blacklisting later if needed.
    """
    return {"message": "Logged out successfully"}
