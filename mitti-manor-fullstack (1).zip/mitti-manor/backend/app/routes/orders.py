from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_active_admin, get_current_user
from app.database.mongodb import get_database
from app.schemas.order import CheckoutRequest, OrderItemOut, OrderOut, OrderStatusUpdateRequest, ORDER_STATUSES
from app.services.order_service import generate_order_number, resolve_unit_price

router = APIRouter(prefix="/api/orders", tags=["Orders"])


async def _resolve_delivery_address(db, current_user: dict, payload: CheckoutRequest) -> dict:
    if payload.address_id:
        address = await db.addresses.find_one(
            {"_id": ObjectId(payload.address_id), "user_id": current_user["_id"]}
        )
        if not address:
            raise HTTPException(status_code=404, detail="Address not found")
        address.pop("_id", None)
        address.pop("user_id", None)
        return address

    if payload.new_address:
        new_addr_doc = {
            **payload.new_address.model_dump(),
            "user_id": current_user["_id"],
            "created_at": datetime.now(timezone.utc),
        }
        await db.addresses.insert_one(new_addr_doc)
        new_addr_doc.pop("_id", None)
        new_addr_doc.pop("user_id", None)
        return new_addr_doc

    raise HTTPException(status_code=400, detail="Provide either address_id or new_address")


async def _order_with_items(db: AsyncIOMotorDatabase, order: dict) -> OrderOut:
    items_cursor = db.order_items.find({"order_id": order["_id"]})
    items = await items_cursor.to_list(length=200)
    order_items = [
        OrderItemOut(
            product_id=i["product_id"],
            product_name=i["product_name"],
            unit_price=i["unit_price"],
            quantity=i["quantity"],
            line_total=i["line_total"],
        )
        for i in items
    ]
    return OrderOut(id=order["_id"], **{k: v for k, v in order.items() if k != "_id"}, items=order_items)


@router.post("/checkout", response_model=OrderOut, status_code=201)
async def checkout(
    payload: CheckoutRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    cart = await db.carts.find_one({"user_id": current_user["_id"]})
    if not cart or not cart.get("items"):
        raise HTTPException(status_code=400, detail="Your cart is empty")

    delivery_address = await _resolve_delivery_address(db, current_user, payload)

    # Validate stock & compute line items
    line_items = []
    subtotal = 0.0
    total_items = 0

    for cart_item in cart["items"]:
        product = await db.products.find_one({"_id": cart_item["product_id"], "is_active": True})
        if not product:
            raise HTTPException(status_code=400, detail="One of the items in your cart is no longer available")
        if cart_item["quantity"] > product["stock"]:
            raise HTTPException(
                status_code=400, detail=f"Insufficient stock for {product['name']} (only {product['stock']} left)"
            )
        unit_price = resolve_unit_price(product["wholesale_price"], product.get("bulk_pricing", []), cart_item["quantity"])
        line_total = unit_price * cart_item["quantity"]
        subtotal += line_total
        total_items += cart_item["quantity"]
        line_items.append(
            {
                "product_id": product["_id"],
                "product_name": product["name"],
                "unit_price": unit_price,
                "quantity": cart_item["quantity"],
                "line_total": line_total,
            }
        )

    now = datetime.now(timezone.utc)
    order_doc = {
        "order_number": generate_order_number(),
        "user_id": current_user["_id"],
        "delivery_address": delivery_address,
        "items_subtotal": subtotal,
        "total_amount": subtotal,  # no taxes/shipping/payment gateway yet by design
        "total_items": total_items,
        "status": "pending",
        "status_history": [{"status": "pending", "at": now}],
        "notes": payload.notes,
        "created_at": now,
        "updated_at": now,
    }
    result = await db.orders.insert_one(order_doc)
    order_doc["_id"] = result.inserted_id

    for item in line_items:
        item["order_id"] = order_doc["_id"]
        await db.order_items.insert_one(item)
        # Decrement stock
        await db.products.update_one({"_id": item["product_id"]}, {"$inc": {"stock": -item["quantity"]}})

    # Clear the cart after a successful order
    await db.carts.update_one({"user_id": current_user["_id"]}, {"$set": {"items": []}})

    return await _order_with_items(db, order_doc)


@router.get("", response_model=list[OrderOut])
async def my_orders(
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    cursor = db.orders.find({"user_id": current_user["_id"]}).sort("created_at", -1)
    orders = await cursor.to_list(length=200)
    return [await _order_with_items(db, o) for o in orders]


@router.get("/{order_id}", response_model=OrderOut)
async def order_details(
    order_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    order = await db.orders.find_one({"_id": ObjectId(order_id), "user_id": current_user["_id"]})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return await _order_with_items(db, order)


# ---- Admin-ready endpoints (protected; requires role == "admin") ----

@router.get("/admin/all", response_model=list[OrderOut])
async def list_all_orders(
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    cursor = db.orders.find({}).sort("created_at", -1)
    orders = await cursor.to_list(length=500)
    return [await _order_with_items(db, o) for o in orders]


@router.put("/admin/{order_id}/status", response_model=OrderOut)
async def update_order_status(
    order_id: str,
    payload: OrderStatusUpdateRequest,
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    if payload.status not in ORDER_STATUSES:
        raise HTTPException(status_code=400, detail=f"status must be one of {ORDER_STATUSES}")

    now = datetime.now(timezone.utc)
    result = await db.orders.update_one(
        {"_id": ObjectId(order_id)},
        {
            "$set": {"status": payload.status, "updated_at": now},
            "$push": {"status_history": {"status": payload.status, "at": now}},
        },
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Order not found")

    order = await db.orders.find_one({"_id": ObjectId(order_id)})
    return await _order_with_items(db, order)
