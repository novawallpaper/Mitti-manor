from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_user
from app.database.mongodb import get_database
from app.schemas.user import UserOut, UserUpdateRequest

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("/me", response_model=UserOut)
async def get_profile(current_user: dict = Depends(get_current_user)):
    return UserOut(id=current_user["_id"], **{k: v for k, v in current_user.items() if k != "_id"})


@router.put("/me", response_model=UserOut)
async def update_profile(
    payload: UserUpdateRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    update_data = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None}
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    if "email" in update_data:
        existing = await db.users.find_one(
            {"email": update_data["email"], "_id": {"$ne": current_user["_id"]}}
        )
        if existing:
            raise HTTPException(status_code=400, detail="Email already in use")

    update_data["updated_at"] = datetime.now(timezone.utc)
    await db.users.update_one({"_id": current_user["_id"]}, {"$set": update_data})
    updated = await db.users.find_one({"_id": current_user["_id"]})
    return UserOut(id=updated["_id"], **{k: v for k, v in updated.items() if k != "_id"})
