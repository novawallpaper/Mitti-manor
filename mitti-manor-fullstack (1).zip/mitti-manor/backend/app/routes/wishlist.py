from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_user
from app.database.mongodb import get_database
from app.schemas.cart import WishlistOut
from app.schemas.product import ProductOut

router = APIRouter(prefix="/api/wishlist", tags=["Wishlist"])


@router.get("", response_model=list[WishlistOut])
async def get_wishlist(
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    cursor = db.wishlists.find({"user_id": current_user["_id"]})
    entries = await cursor.to_list(length=200)

    results = []
    for entry in entries:
        product = await db.products.find_one({"_id": entry["product_id"], "is_active": True})
        if not product:
            continue
        results.append(
            WishlistOut(
                id=entry["_id"],
                product=ProductOut(id=product["_id"], **{k: v for k, v in product.items() if k != "_id"}),
            )
        )
    return results


@router.post("/{product_id}", status_code=201)
async def add_to_wishlist(
    product_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    product = await db.products.find_one({"_id": ObjectId(product_id)})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    try:
        await db.wishlists.insert_one(
            {
                "user_id": current_user["_id"],
                "product_id": ObjectId(product_id),
                "created_at": datetime.now(timezone.utc),
            }
        )
    except Exception:
        pass  # already in wishlist — unique index prevents duplicates
    return {"message": "Added to wishlist"}


@router.delete("/{product_id}", status_code=204)
async def remove_from_wishlist(
    product_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    await db.wishlists.delete_one({"user_id": current_user["_id"], "product_id": ObjectId(product_id)})
