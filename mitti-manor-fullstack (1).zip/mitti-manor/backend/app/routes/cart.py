from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_user
from app.database.mongodb import get_database
from app.schemas.cart import CartItemOut, CartItemRequest, CartOut
from app.schemas.product import ProductOut
from app.services.order_service import resolve_unit_price

router = APIRouter(prefix="/api/cart", tags=["Cart"])


async def _build_cart_response(db: AsyncIOMotorDatabase, cart: dict | None) -> CartOut:
    if not cart or not cart.get("items"):
        return CartOut(items=[], subtotal=0, total_items=0)

    items_out = []
    subtotal = 0.0
    total_items = 0

    for item in cart["items"]:
        product = await db.products.find_one({"_id": item["product_id"], "is_active": True})
        if not product:
            continue
        unit_price = resolve_unit_price(product["wholesale_price"], product.get("bulk_pricing", []), item["quantity"])
        line_total = unit_price * item["quantity"]
        subtotal += line_total
        total_items += item["quantity"]
        items_out.append(
            CartItemOut(
                product=ProductOut(id=product["_id"], **{k: v for k, v in product.items() if k != "_id"}),
                quantity=item["quantity"],
                unit_price_applied=unit_price,
                line_total=line_total,
            )
        )

    return CartOut(items=items_out, subtotal=subtotal, total_items=total_items)


@router.get("", response_model=CartOut)
async def get_cart(
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    cart = await db.carts.find_one({"user_id": current_user["_id"]})
    return await _build_cart_response(db, cart)


@router.post("/items", response_model=CartOut)
async def add_or_update_item(
    payload: CartItemRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    product = await db.products.find_one({"_id": ObjectId(payload.product_id), "is_active": True})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    if payload.quantity < product["moq"]:
        raise HTTPException(status_code=400, detail=f"Minimum order quantity for this product is {product['moq']}")
    if payload.quantity > product["stock"]:
        raise HTTPException(status_code=400, detail=f"Only {product['stock']} units in stock")

    cart = await db.carts.find_one({"user_id": current_user["_id"]})
    now = datetime.now(timezone.utc)

    if not cart:
        await db.carts.insert_one(
            {
                "user_id": current_user["_id"],
                "items": [{"product_id": product["_id"], "quantity": payload.quantity}],
                "updated_at": now,
            }
        )
    else:
        items = cart.get("items", [])
        found = False
        for item in items:
            if item["product_id"] == product["_id"]:
                item["quantity"] = payload.quantity
                found = True
                break
        if not found:
            items.append({"product_id": product["_id"], "quantity": payload.quantity})
        await db.carts.update_one(
            {"user_id": current_user["_id"]}, {"$set": {"items": items, "updated_at": now}}
        )

    cart = await db.carts.find_one({"user_id": current_user["_id"]})
    return await _build_cart_response(db, cart)


@router.delete("/items/{product_id}", response_model=CartOut)
async def remove_item(
    product_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    await db.carts.update_one(
        {"user_id": current_user["_id"]},
        {"$pull": {"items": {"product_id": ObjectId(product_id)}}},
    )
    cart = await db.carts.find_one({"user_id": current_user["_id"]})
    return await _build_cart_response(db, cart)


@router.delete("", response_model=CartOut)
async def clear_cart(
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    await db.carts.update_one({"user_id": current_user["_id"]}, {"$set": {"items": []}})
    return CartOut(items=[], subtotal=0, total_items=0)
