from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_user
from app.database.mongodb import get_database
from app.schemas.business import BusinessOut, BusinessUpsertRequest

router = APIRouter(prefix="/api/business", tags=["Business Profile"])


@router.get("/me", response_model=BusinessOut)
async def get_my_business(
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    business = await db.businesses.find_one({"user_id": current_user["_id"]})
    if not business:
        raise HTTPException(status_code=404, detail="Business profile not created yet")
    return BusinessOut(id=business["_id"], **{k: v for k, v in business.items() if k != "_id"})


@router.put("/me", response_model=BusinessOut)
async def upsert_my_business(
    payload: BusinessUpsertRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    now = datetime.now(timezone.utc)
    update_doc = {**payload.model_dump(), "user_id": current_user["_id"], "updated_at": now}

    await db.businesses.update_one(
        {"user_id": current_user["_id"]},
        {"$set": update_doc, "$setOnInsert": {"created_at": now}},
        upsert=True,
    )
    business = await db.businesses.find_one({"user_id": current_user["_id"]})
    return BusinessOut(id=business["_id"], **{k: v for k, v in business.items() if k != "_id"})
