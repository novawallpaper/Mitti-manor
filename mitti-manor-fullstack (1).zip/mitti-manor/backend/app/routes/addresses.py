from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_user
from app.database.mongodb import get_database
from app.schemas.address import AddressCreateRequest, AddressOut

router = APIRouter(prefix="/api/addresses", tags=["Addresses"])


@router.get("", response_model=list[AddressOut])
async def list_addresses(
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    cursor = db.addresses.find({"user_id": current_user["_id"]}).sort("is_default", -1)
    addresses = await cursor.to_list(length=50)
    return [AddressOut(id=a["_id"], **{k: v for k, v in a.items() if k != "_id"}) for a in addresses]


@router.post("", response_model=AddressOut, status_code=201)
async def create_address(
    payload: AddressCreateRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    if payload.is_default:
        await db.addresses.update_many({"user_id": current_user["_id"]}, {"$set": {"is_default": False}})

    doc = {
        **payload.model_dump(),
        "user_id": current_user["_id"],
        "created_at": datetime.now(timezone.utc),
    }
    result = await db.addresses.insert_one(doc)
    doc["_id"] = result.inserted_id
    return AddressOut(id=doc["_id"], **{k: v for k, v in doc.items() if k != "_id"})


@router.delete("/{address_id}", status_code=204)
async def delete_address(
    address_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    result = await db.addresses.delete_one({"_id": ObjectId(address_id), "user_id": current_user["_id"]})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Address not found")
