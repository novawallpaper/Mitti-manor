import re
from datetime import datetime, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Query
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.deps import get_current_active_admin
from app.database.mongodb import get_database
from app.schemas.product import ProductCreateRequest, ProductListResponse, ProductOut, ProductUpdateRequest

router = APIRouter(prefix="/api/products", tags=["Products"])


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


async def _attach_category_name(db: AsyncIOMotorDatabase, product: dict) -> dict:
    category = await db.categories.find_one({"_id": product["category_id"]})
    product["category_name"] = category["name"] if category else None
    return product


def _to_out(product: dict) -> ProductOut:
    return ProductOut(id=product["_id"], **{k: v for k, v in product.items() if k != "_id"})


@router.get("", response_model=ProductListResponse)
async def list_products(
    search: str | None = Query(default=None, description="Search by product name/description"),
    category_id: str | None = Query(default=None),
    min_price: float | None = Query(default=None),
    max_price: float | None = Query(default=None),
    sort_by: str = Query(default="created_at", pattern="^(created_at|wholesale_price|name)$"),
    sort_order: str = Query(default="desc", pattern="^(asc|desc)$"),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    query: dict = {"is_active": True}

    if search:
        query["$or"] = [
            {"name": {"$regex": re.escape(search), "$options": "i"}},
            {"description": {"$regex": re.escape(search), "$options": "i"}},
        ]
    if category_id:
        query["category_id"] = ObjectId(category_id)
    if min_price is not None or max_price is not None:
        price_filter = {}
        if min_price is not None:
            price_filter["$gte"] = min_price
        if max_price is not None:
            price_filter["$lte"] = max_price
        query["wholesale_price"] = price_filter

    total = await db.products.count_documents(query)
    sort_direction = 1 if sort_order == "asc" else -1

    cursor = (
        db.products.find(query)
        .sort(sort_by, sort_direction)
        .skip((page - 1) * page_size)
        .limit(page_size)
    )
    products = await cursor.to_list(length=page_size)
    products = [await _attach_category_name(db, p) for p in products]

    return ProductListResponse(
        items=[_to_out(p) for p in products], total=total, page=page, page_size=page_size
    )


@router.get("/{product_id_or_slug}", response_model=ProductOut)
async def get_product(product_id_or_slug: str, db: AsyncIOMotorDatabase = Depends(get_database)):
    query = {"_id": ObjectId(product_id_or_slug)} if ObjectId.is_valid(product_id_or_slug) else {
        "slug": product_id_or_slug
    }
    product = await db.products.find_one({**query, "is_active": True})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    product = await _attach_category_name(db, product)
    return _to_out(product)


# ---- Admin-ready CRUD (protected; requires role == "admin") ----

@router.post("", response_model=ProductOut, status_code=201)
async def create_product(
    payload: ProductCreateRequest,
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    category = await db.categories.find_one({"_id": ObjectId(payload.category_id)})
    if not category:
        raise HTTPException(status_code=400, detail="Invalid category_id")

    now = datetime.now(timezone.utc)
    slug = slugify(payload.name)
    doc = {
        **payload.model_dump(exclude={"category_id", "bulk_pricing"}),
        "category_id": ObjectId(payload.category_id),
        "bulk_pricing": [t.model_dump() for t in payload.bulk_pricing],
        "slug": slug,
        "is_active": True,
        "created_at": now,
        "updated_at": now,
    }
    result = await db.products.insert_one(doc)
    doc["_id"] = result.inserted_id
    doc = await _attach_category_name(db, doc)
    return _to_out(doc)


@router.put("/{product_id}", response_model=ProductOut)
async def update_product(
    product_id: str,
    payload: ProductUpdateRequest,
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    update_data = payload.model_dump(exclude_unset=True)
    if "category_id" in update_data:
        update_data["category_id"] = ObjectId(update_data["category_id"])
    if "bulk_pricing" in update_data:
        update_data["bulk_pricing"] = [t if isinstance(t, dict) else t.model_dump() for t in update_data["bulk_pricing"]]
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    update_data["updated_at"] = datetime.now(timezone.utc)
    result = await db.products.update_one({"_id": ObjectId(product_id)}, {"$set": update_data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")

    product = await db.products.find_one({"_id": ObjectId(product_id)})
    product = await _attach_category_name(db, product)
    return _to_out(product)


@router.delete("/{product_id}", status_code=204)
async def delete_product(
    product_id: str,
    _admin: dict = Depends(get_current_active_admin),
    db: AsyncIOMotorDatabase = Depends(get_database),
):
    """Soft delete — keeps historical order data intact."""
    await db.products.update_one({"_id": ObjectId(product_id)}, {"$set": {"is_active": False}})
