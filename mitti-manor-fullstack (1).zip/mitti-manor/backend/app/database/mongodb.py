"""
MongoDB connection layer.

Uses Motor (the official async MongoDB driver) so FastAPI's async routes
never block on database I/O. A single client is created on app startup and
shared across the whole application (see app/main.py lifespan).
"""
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

from app.core.config import settings


class MongoDB:
    client: AsyncIOMotorClient | None = None
    db: AsyncIOMotorDatabase | None = None


mongodb = MongoDB()


async def connect_to_mongo() -> None:
    mongodb.client = AsyncIOMotorClient(settings.MONGO_URI)
    mongodb.db = mongodb.client[settings.MONGO_DB_NAME]
    await create_indexes()


async def close_mongo_connection() -> None:
    if mongodb.client:
        mongodb.client.close()


def get_database() -> AsyncIOMotorDatabase:
    """Dependency-friendly accessor for the active database handle."""
    if mongodb.db is None:
        raise RuntimeError("Database not initialized. Did startup run?")
    return mongodb.db


async def create_indexes() -> None:
    """
    Indexes reflect the relationships between collections:
    users -> businesses -> addresses
    products -> categories
    orders -> order_items, users, addresses
    wishlists -> users, products
    """
    db = mongodb.db

    await db.users.create_index("mobile", unique=True)
    await db.users.create_index("email", unique=True, sparse=True)

    await db.businesses.create_index("user_id", unique=True)
    await db.businesses.create_index("gstin", sparse=True)

    await db.categories.create_index("slug", unique=True)

    await db.products.create_index("slug", unique=True)
    await db.products.create_index("category_id")
    await db.products.create_index([("name", "text"), ("description", "text")])

    await db.addresses.create_index("user_id")

    await db.orders.create_index("order_number", unique=True)
    await db.orders.create_index("user_id")
    await db.orders.create_index("status")

    await db.order_items.create_index("order_id")
    await db.order_items.create_index("product_id")

    await db.wishlists.create_index([("user_id", 1), ("product_id", 1)], unique=True)

    await db.carts.create_index("user_id", unique=True)
