from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.database.mongodb import close_mongo_connection, connect_to_mongo
from app.routes import addresses, auth, business, cart, categories, orders, products, users, wishlist


@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_to_mongo()
    yield
    await close_mongo_connection()


app = FastAPI(
    title="MITTI MANOR API",
    description="B2B wholesale e-commerce API for disposable products.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Return clean, consistent validation error messages to the frontend."""
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()},
    )


app.include_router(auth.router)
app.include_router(users.router)
app.include_router(business.router)
app.include_router(categories.router)
app.include_router(products.router)
app.include_router(cart.router)
app.include_router(wishlist.router)
app.include_router(addresses.router)
app.include_router(orders.router)


@app.get("/api/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "service": "MITTI MANOR API", "environment": settings.ENVIRONMENT}


@app.get("/", tags=["Health"])
async def root():
    return {"message": "MITTI MANOR API is running. See /docs for API documentation."}
