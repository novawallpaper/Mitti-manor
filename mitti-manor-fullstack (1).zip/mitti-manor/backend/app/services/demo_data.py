"""
Demo/seed data for the first development version of MITTI MANOR.

Run via `python seed_db.py` from the backend/ folder. Safe to re-run —
it upserts by slug so it won't create duplicates.
"""
from datetime import datetime, timezone

from motor.motor_asyncio import AsyncIOMotorDatabase

DEMO_CATEGORIES = [
    {
        "name": "Disposable Cutlery",
        "slug": "disposable-cutlery",
        "description": "Bulk disposable spoons, forks, knives for restaurants and events.",
        "image_url": "https://images.unsplash.com/photo-1584473457406-6240486418e9?w=600",
    },
    {
        "name": "Paper Cups & Glasses",
        "slug": "paper-cups-glasses",
        "description": "Wholesale paper cups and glasses in bulk cartons.",
        "image_url": "https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=600",
    },
    {
        "name": "Food Packaging Boxes",
        "slug": "food-packaging-boxes",
        "description": "Takeaway boxes and containers for cafes and cloud kitchens.",
        "image_url": "https://images.unsplash.com/photo-1606787366850-de6330128bfc?w=600",
    },
    {
        "name": "Disposable Plates & Bowls",
        "slug": "disposable-plates-bowls",
        "description": "Areca leaf, paper and bagasse plates & bowls in bulk.",
        "image_url": "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=600",
    },
    {
        "name": "Napkins & Tissues",
        "slug": "napkins-tissues",
        "description": "Bulk paper napkins and tissue rolls for HORECA.",
        "image_url": "https://images.unsplash.com/photo-1583947581924-860bda6a26df?w=600",
    },
]

DEMO_PRODUCTS = [
    {
        "name": "Biodegradable Wooden Spoons (Pack of 100)",
        "slug": "biodegradable-wooden-spoons-100",
        "category_slug": "disposable-cutlery",
        "description": "Eco-friendly disposable wooden spoons, sturdy and biodegradable. Ideal for restaurants, cafes and catering events.",
        "specifications": {"Material": "Birch Wood", "Pack Size": "100 pcs", "Length": "16 cm"},
        "images": ["https://images.unsplash.com/photo-1584473457406-6240486418e9?w=600"],
        "unit": "carton (100 packs)",
        "wholesale_price": 45.0,
        "moq": 10,
        "stock": 500,
        "bulk_pricing": [
            {"min_qty": 10, "price_per_unit": 45.0},
            {"min_qty": 50, "price_per_unit": 40.0},
            {"min_qty": 100, "price_per_unit": 35.0},
        ],
    },
    {
        "name": "Clear Plastic Forks (Pack of 100)",
        "slug": "clear-plastic-forks-100",
        "category_slug": "disposable-cutlery",
        "description": "Durable clear plastic forks, food-grade, perfect for bulk catering and takeaway orders.",
        "specifications": {"Material": "PP Plastic", "Pack Size": "100 pcs"},
        "images": ["https://images.unsplash.com/photo-1615486511262-79f22ea6c4d3?w=600"],
        "unit": "carton (100 packs)",
        "wholesale_price": 38.0,
        "moq": 10,
        "stock": 800,
        "bulk_pricing": [
            {"min_qty": 10, "price_per_unit": 38.0},
            {"min_qty": 50, "price_per_unit": 34.0},
        ],
    },
    {
        "name": "Paper Cups 150ml (Sleeve of 50)",
        "slug": "paper-cups-150ml-50",
        "category_slug": "paper-cups-glasses",
        "description": "Single-use paper cups, leak-proof, great for tea/coffee stalls, offices and events.",
        "specifications": {"Capacity": "150 ml", "Pack Size": "50 pcs", "Material": "Food-grade Paper"},
        "images": ["https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=600"],
        "unit": "box (20 sleeves)",
        "wholesale_price": 220.0,
        "moq": 5,
        "stock": 300,
        "bulk_pricing": [
            {"min_qty": 5, "price_per_unit": 220.0},
            {"min_qty": 20, "price_per_unit": 200.0},
        ],
    },
    {
        "name": "Double Wall Paper Coffee Cups 250ml (Sleeve of 50)",
        "slug": "double-wall-coffee-cups-250ml",
        "category_slug": "paper-cups-glasses",
        "description": "Insulated double-wall paper cups for hot beverages — keeps hands cool and drinks hot.",
        "specifications": {"Capacity": "250 ml", "Pack Size": "50 pcs"},
        "images": ["https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600"],
        "unit": "box (20 sleeves)",
        "wholesale_price": 480.0,
        "moq": 3,
        "stock": 150,
        "bulk_pricing": [{"min_qty": 3, "price_per_unit": 480.0}, {"min_qty": 10, "price_per_unit": 450.0}],
    },
    {
        "name": "Kraft Paper Takeaway Boxes 750ml (Pack of 50)",
        "slug": "kraft-takeaway-boxes-750ml",
        "category_slug": "food-packaging-boxes",
        "description": "Grease-resistant kraft paper boxes for takeaway meals — microwave safe.",
        "specifications": {"Capacity": "750 ml", "Pack Size": "50 pcs", "Material": "Kraft Paper"},
        "images": ["https://images.unsplash.com/photo-1606787366850-de6330128bfc?w=600"],
        "unit": "carton (50 packs)",
        "wholesale_price": 650.0,
        "moq": 5,
        "stock": 200,
        "bulk_pricing": [{"min_qty": 5, "price_per_unit": 650.0}, {"min_qty": 20, "price_per_unit": 600.0}],
    },
    {
        "name": "Areca Leaf Round Plates 10-inch (Pack of 25)",
        "slug": "areca-leaf-plates-10in",
        "category_slug": "disposable-plates-bowls",
        "description": "100% natural, chemical-free areca leaf plates. Sturdy, biodegradable and microwave safe.",
        "specifications": {"Diameter": "10 inch", "Pack Size": "25 pcs", "Material": "Areca Leaf"},
        "images": ["https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=600"],
        "unit": "carton (25 packs)",
        "wholesale_price": 900.0,
        "moq": 2,
        "stock": 120,
        "bulk_pricing": [{"min_qty": 2, "price_per_unit": 900.0}, {"min_qty": 10, "price_per_unit": 840.0}],
    },
    {
        "name": "Bagasse Clamshell Boxes 3-compartment (Pack of 50)",
        "slug": "bagasse-clamshell-3comp",
        "category_slug": "food-packaging-boxes",
        "description": "Sugarcane bagasse clamshell containers, oil and heat resistant, great for buffets and thalis.",
        "specifications": {"Compartments": "3", "Pack Size": "50 pcs", "Material": "Bagasse"},
        "images": ["https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600"],
        "unit": "carton (50 packs)",
        "wholesale_price": 780.0,
        "moq": 4,
        "stock": 160,
        "bulk_pricing": [{"min_qty": 4, "price_per_unit": 780.0}, {"min_qty": 15, "price_per_unit": 730.0}],
    },
    {
        "name": "Plain Paper Napkins 30x30cm (Pack of 100)",
        "slug": "paper-napkins-30x30",
        "category_slug": "napkins-tissues",
        "description": "Soft 1-ply paper napkins, ideal for restaurants, canteens and events.",
        "specifications": {"Size": "30x30 cm", "Pack Size": "100 pcs", "Ply": "1"},
        "images": ["https://images.unsplash.com/photo-1583947581924-860bda6a26df?w=600"],
        "unit": "carton (40 packs)",
        "wholesale_price": 520.0,
        "moq": 3,
        "stock": 250,
        "bulk_pricing": [{"min_qty": 3, "price_per_unit": 520.0}, {"min_qty": 12, "price_per_unit": 480.0}],
    },
]


async def seed_demo_data(db: AsyncIOMotorDatabase) -> None:
    now = datetime.now(timezone.utc)

    category_slug_to_id = {}
    for cat in DEMO_CATEGORIES:
        doc = {**cat, "is_active": True, "created_at": now}
        result = await db.categories.update_one(
            {"slug": cat["slug"]}, {"$set": doc}, upsert=True
        )
        if result.upserted_id:
            category_slug_to_id[cat["slug"]] = result.upserted_id
        else:
            existing = await db.categories.find_one({"slug": cat["slug"]})
            category_slug_to_id[cat["slug"]] = existing["_id"]

    for prod in DEMO_PRODUCTS:
        category_id = category_slug_to_id[prod["category_slug"]]
        doc = {
            "name": prod["name"],
            "slug": prod["slug"],
            "category_id": category_id,
            "description": prod["description"],
            "specifications": prod["specifications"],
            "images": prod["images"],
            "unit": prod["unit"],
            "wholesale_price": prod["wholesale_price"],
            "moq": prod["moq"],
            "stock": prod["stock"],
            "bulk_pricing": prod["bulk_pricing"],
            "is_active": True,
            "updated_at": now,
        }
        await db.products.update_one(
            {"slug": prod["slug"]},
            {"$set": doc, "$setOnInsert": {"created_at": now}},
            upsert=True,
        )

    print(f"Seeded {len(DEMO_CATEGORIES)} categories and {len(DEMO_PRODUCTS)} products.")
