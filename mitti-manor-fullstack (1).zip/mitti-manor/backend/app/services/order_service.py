"""
Business logic for pricing and order-number generation, kept out of the
route handlers so it can be reused (e.g. by a future admin dashboard or
a bulk-import script) without duplicating logic.
"""
import random
from datetime import datetime, timezone


def resolve_unit_price(wholesale_price: float, bulk_pricing: list[dict], quantity: int) -> float:
    """
    Given a product's base wholesale price and its bulk pricing tiers,
    return the price-per-unit that applies for the requested quantity.
    Tiers are matched by the highest `min_qty` that is <= quantity.
    """
    applicable_price = wholesale_price
    best_min_qty = 0
    for tier in bulk_pricing:
        min_qty = tier["min_qty"] if isinstance(tier, dict) else tier.min_qty
        price = tier["price_per_unit"] if isinstance(tier, dict) else tier.price_per_unit
        if quantity >= min_qty and min_qty >= best_min_qty:
            best_min_qty = min_qty
            applicable_price = price
    return applicable_price


def generate_order_number() -> str:
    today = datetime.now(timezone.utc).strftime("%Y%m%d")
    suffix = random.randint(1000, 9999)
    return f"MM-{today}-{suffix}"
