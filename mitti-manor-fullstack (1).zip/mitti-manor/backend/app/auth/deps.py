"""
FastAPI dependencies used to protect private routes.

Usage in a route:

    @router.get("/me")
    async def me(current_user: dict = Depends(get_current_user)):
        ...
"""
from bson import ObjectId
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.auth.security import decode_access_token
from app.database.mongodb import get_database

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login", auto_error=False)

CREDENTIALS_EXCEPTION = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


async def get_current_user(
    token: str | None = Depends(oauth2_scheme),
    db: AsyncIOMotorDatabase = Depends(get_database),
) -> dict:
    if not token:
        raise CREDENTIALS_EXCEPTION

    user_id = decode_access_token(token)
    if not user_id:
        raise CREDENTIALS_EXCEPTION

    user = await db.users.find_one({"_id": ObjectId(user_id)})
    if not user:
        raise CREDENTIALS_EXCEPTION
    if not user.get("is_active", True):
        raise HTTPException(status_code=403, detail="Account is disabled")

    return user


async def get_current_active_admin(
    current_user: dict = Depends(get_current_user),
) -> dict:
    """
    Admin-ready hook: routes that should eventually be admin-only can
    depend on this instead of get_current_user. Today it just checks a
    `role` field on the user document (defaults to 'customer').
    """
    if current_user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin privileges required")
    return current_user
