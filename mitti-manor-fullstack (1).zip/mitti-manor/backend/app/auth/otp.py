"""
OTP service — DEMO MODE.

This module deliberately isolates all OTP logic behind a small interface
(`send_otp`, `verify_otp`) so that swapping in a real SMS provider later
(Twilio, MSG91, AWS SNS, etc.) means editing ONLY this file — nothing in
the routes or frontend needs to change.

DEMO BEHAVIOUR:
- `send_otp` doesn't call any SMS API. It just stores a fixed/generated
  code in-memory (or you could persist it in Mongo) and returns it in the
  API response so the frontend can display it during development.
- `verify_otp` accepts the DEMO_OTP_CODE from settings for ANY mobile
  number. This is intentionally insecure and MUST be replaced before
  going to production.
"""
from datetime import datetime, timedelta, timezone

from app.core.config import settings

# In-memory store: { mobile: {"code": str, "expires_at": datetime} }
# NOTE: for a real deployment, replace this with a Mongo collection
# (e.g. `otp_codes`) or a Redis store so it survives restarts / scales
# across multiple server instances.
_otp_store: dict[str, dict] = {}


def send_otp(mobile: str) -> str:
    """
    DEMO: 'sends' an OTP by generating/storing a fixed demo code.
    Replace the body of this function with a real SMS provider call,
    keeping the same signature, when going to production.
    """
    code = settings.DEMO_OTP_CODE
    _otp_store[mobile] = {
        "code": code,
        "expires_at": datetime.now(timezone.utc) + timedelta(minutes=10),
    }
    return code


def verify_otp(mobile: str, code: str) -> bool:
    record = _otp_store.get(mobile)
    if not record:
        # Demo convenience: also accept the global demo code even if
        # send_otp was never explicitly called first.
        return code == settings.DEMO_OTP_CODE
    if datetime.now(timezone.utc) > record["expires_at"]:
        return False
    return code == record["code"]
