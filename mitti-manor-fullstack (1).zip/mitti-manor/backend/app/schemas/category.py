from datetime import datetime

from pydantic import BaseModel

from app.schemas.common import MongoBaseModel, PyObjectId


class CategoryCreateRequest(BaseModel):
    name: str
    description: str | None = None
    image_url: str | None = None


class CategoryOut(MongoBaseModel):
    id: PyObjectId
    name: str
    slug: str
    description: str | None = None
    image_url: str | None = None
    is_active: bool = True
    created_at: datetime
