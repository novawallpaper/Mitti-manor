from datetime import datetime

from pydantic import BaseModel, Field

from app.schemas.address import AddressCreateRequest
from app.schemas.common import MongoBaseModel, PyObjectId

ORDER_STATUSES = [
    "pending",
    "confirmed",
    "processing",
    "shipped",
    "delivered",
    "cancelled",
]


class CheckoutRequest(BaseModel):
    address_id: str | None = None
    new_address: AddressCreateRequest | None = None
    notes: str | None = None


class OrderItemOut(BaseModel):
    product_id: PyObjectId
    product_name: str
    unit_price: float
    quantity: int
    line_total: float


class OrderOut(MongoBaseModel):
    id: PyObjectId
    order_number: str
    user_id: PyObjectId
    delivery_address: dict
    items: list[OrderItemOut] = Field(default_factory=list)
    items_subtotal: float
    total_amount: float
    total_items: int
    status: str
    status_history: list[dict] = Field(default_factory=list)
    notes: str | None = None
    created_at: datetime
    updated_at: datetime


class OrderStatusUpdateRequest(BaseModel):
    status: str

    def validate_status(self):
        if self.status not in ORDER_STATUSES:
            raise ValueError(f"status must be one of {ORDER_STATUSES}")
