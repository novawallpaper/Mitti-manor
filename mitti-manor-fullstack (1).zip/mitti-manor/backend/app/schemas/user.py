from datetime import datetime

from pydantic import BaseModel, EmailStr

from app.schemas.common import MongoBaseModel, PyObjectId


class UserOut(MongoBaseModel):
    id: PyObjectId
    full_name: str
    mobile: str
    email: EmailStr | None = None
    role: str = "customer"
    is_mobile_verified: bool = False
    is_active: bool = True
    created_at: datetime


class UserUpdateRequest(BaseModel):
    full_name: str | None = None
    email: EmailStr | None = None
