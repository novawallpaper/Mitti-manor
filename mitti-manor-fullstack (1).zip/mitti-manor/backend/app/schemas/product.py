from datetime import datetime

from pydantic import BaseModel, Field

from app.schemas.common import MongoBaseModel, PyObjectId


class BulkPricingTier(BaseModel):
    min_qty: int = Field(gt=0)
    price_per_unit: float = Field(gt=0)


class ProductCreateRequest(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    category_id: str
    description: str
    specifications: dict[str, str] = Field(default_factory=dict)
    images: list[str] = Field(default_factory=list)
    unit: str = "unit"
    wholesale_price: float = Field(gt=0)
    moq: int = Field(gt=0)
    stock: int = Field(ge=0)
    bulk_pricing: list[BulkPricingTier] = Field(default_factory=list)


class ProductUpdateRequest(BaseModel):
    name: str | None = None
    category_id: str | None = None
    description: str | None = None
    specifications: dict[str, str] | None = None
    images: list[str] | None = None
    unit: str | None = None
    wholesale_price: float | None = Field(default=None, gt=0)
    moq: int | None = Field(default=None, gt=0)
    stock: int | None = Field(default=None, ge=0)
    bulk_pricing: list[BulkPricingTier] | None = None
    is_active: bool | None = None


class ProductOut(MongoBaseModel):
    id: PyObjectId
    name: str
    slug: str
    category_id: PyObjectId
    category_name: str | None = None
    description: str
    specifications: dict[str, str] = Field(default_factory=dict)
    images: list[str] = Field(default_factory=list)
    unit: str
    wholesale_price: float
    moq: int
    stock: int
    bulk_pricing: list[BulkPricingTier] = Field(default_factory=list)
    is_active: bool = True
    created_at: datetime
    updated_at: datetime


class ProductListResponse(BaseModel):
    items: list[ProductOut]
    total: int
    page: int
    page_size: int
