from pydantic import BaseModel, EmailStr, Field, field_validator


class RegisterRequest(BaseModel):
    full_name: str = Field(min_length=2, max_length=100)
    mobile: str = Field(min_length=10, max_length=15)
    email: EmailStr | None = None
    password: str = Field(min_length=6, max_length=100)

    @field_validator("mobile")
    @classmethod
    def mobile_digits_only(cls, v: str) -> str:
        cleaned = v.strip().replace(" ", "")
        if not cleaned.lstrip("+").isdigit():
            raise ValueError("Mobile number must contain only digits (optionally prefixed with +)")
        return cleaned


class LoginRequest(BaseModel):
    identifier: str = Field(description="Mobile number or email")
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


class SendOtpRequest(BaseModel):
    mobile: str


class SendOtpResponse(BaseModel):
    message: str
    # DEMO ONLY: real SMS integrations must NOT return the code in the API
    # response. It's included here purely so the frontend can display it
    # during development without a live SMS provider.
    demo_otp_code: str


class VerifyOtpRequest(BaseModel):
    mobile: str
    otp_code: str
