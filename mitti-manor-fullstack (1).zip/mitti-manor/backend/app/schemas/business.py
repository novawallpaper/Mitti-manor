from datetime import datetime

from pydantic import BaseModel, Field

from app.schemas.common import MongoBaseModel, PyObjectId


class BusinessUpsertRequest(BaseModel):
    owner_name: str = Field(min_length=2, max_length=100)
    business_name: str = Field(min_length=2, max_length=150)
    mobile: str = Field(min_length=10, max_length=15)
    business_type: str
    gstin: str | None = Field(default=None, max_length=15)
    address: str
    city: str
    state: str
    pincode: str = Field(min_length=4, max_length=10)


class BusinessOut(MongoBaseModel):
    id: PyObjectId
    user_id: PyObjectId
    owner_name: str
    business_name: str
    mobile: str
    business_type: str
    gstin: str | None = None
    address: str
    city: str
    state: str
    pincode: str
    created_at: datetime
    updated_at: datetime
