"""
Shared Pydantic helpers so every schema can represent MongoDB's ObjectId
as a plain string on the API boundary (frontend never sees BSON types).
"""
from typing import Annotated, Any

from bson import ObjectId
from pydantic import BeforeValidator, ConfigDict, BaseModel


def validate_object_id(v: Any) -> str:
    if isinstance(v, ObjectId):
        return str(v)
    if isinstance(v, str) and ObjectId.is_valid(v):
        return v
    raise ValueError("Invalid ObjectId")


PyObjectId = Annotated[str, BeforeValidator(validate_object_id)]


class MongoBaseModel(BaseModel):
    """Base for schemas that are read directly out of Mongo documents."""

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)
