from pydantic import BaseModel, Field

from app.schemas.common import MongoBaseModel, PyObjectId
from app.schemas.product import ProductOut


class CartItemRequest(BaseModel):
    product_id: str
    quantity: int = Field(gt=0)


class CartItemOut(BaseModel):
    product: ProductOut
    quantity: int
    line_total: float
    unit_price_applied: float


class CartOut(BaseModel):
    items: list[CartItemOut]
    subtotal: float
    total_items: int


class WishlistOut(MongoBaseModel):
    id: PyObjectId
    product: ProductOut
