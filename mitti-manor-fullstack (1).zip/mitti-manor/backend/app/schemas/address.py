from datetime import datetime

from pydantic import BaseModel, Field

from app.schemas.common import MongoBaseModel, PyObjectId


class AddressCreateRequest(BaseModel):
    label: str = "Shop"
    contact_name: str
    contact_mobile: str
    address_line1: str
    address_line2: str | None = None
    city: str
    state: str
    pincode: str = Field(min_length=4, max_length=10)
    is_default: bool = False


class AddressOut(MongoBaseModel):
    id: PyObjectId
    user_id: PyObjectId
    label: str
    contact_name: str
    contact_mobile: str
    address_line1: str
    address_line2: str | None = None
    city: str
    state: str
    pincode: str
    is_default: bool
    created_at: datetime
