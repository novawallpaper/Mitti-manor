"""
Run this once to populate the database with demo categories/products,
and optionally create a demo admin account.

Usage:
    python seed_db.py
"""
import asyncio
from datetime import datetime, timezone

from motor.motor_asyncio import AsyncIOMotorClient

from app.auth.security import hash_password
from app.core.config import settings
from app.services.demo_data import seed_demo_data

DEMO_ADMIN_MOBILE = "9999999999"
DEMO_ADMIN_PASSWORD = "admin123"


async def main():
    client = AsyncIOMotorClient(settings.MONGO_URI)
    db = client[settings.MONGO_DB_NAME]

    await seed_demo_data(db)

    existing_admin = await db.users.find_one({"mobile": DEMO_ADMIN_MOBILE})
    if not existing_admin:
        now = datetime.now(timezone.utc)
        await db.users.insert_one(
            {
                "full_name": "MITTI MANOR Admin",
                "mobile": DEMO_ADMIN_MOBILE,
                "email": "admin@mittimanor.demo",
                "hashed_password": hash_password(DEMO_ADMIN_PASSWORD),
                "role": "admin",
                "is_mobile_verified": True,
                "is_active": True,
                "created_at": now,
                "updated_at": now,
            }
        )
        print(f"Created demo admin -> mobile: {DEMO_ADMIN_MOBILE}, password: {DEMO_ADMIN_PASSWORD}")
    else:
        print("Demo admin already exists.")

    client.close()


if __name__ == "__main__":
    asyncio.run(main())
